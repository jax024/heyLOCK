package com.applock.lock.apps.fingerprint.password.navigation.vault

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.activity.FileListActivity
import com.applock.lock.apps.fingerprint.password.activity.FolderListActivity
import com.applock.lock.apps.fingerprint.password.activity.VaultFileListActivity
import com.applock.lock.apps.fingerprint.password.databinding.FragmentVaultBinding
import com.applock.lock.apps.fingerprint.password.utils.ALL_FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.AUDIO_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.AUDIO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.FILE_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.IS_FROM_VAULT
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.SELECTED_VAULT_CAT
import com.applock.lock.apps.fingerprint.password.utils.TYPE
import com.applock.lock.apps.fingerprint.password.utils.VAULT_ALL_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VAULT_AUDIO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VAULT_FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VAULT_PHOTO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VAULT_VIDEO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VIDEO_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.VIDEO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.gone
import com.applock.lock.apps.fingerprint.password.utils.visible
import com.bumptech.glide.Glide
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers

import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors

class VaultFragment : Fragment(), FolderListAdapter.OnItemClickListener,
    VaultListAdapter.OnItemClickListener {

    var fragmentActivity: FragmentActivity? = null

    var isPefresh = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentVaultBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init()

    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        fragmentActivity = context as FragmentActivity
    }

    private fun init() {
        catPhotoSelected(requireActivity())

        lifecycleScope.launch(Dispatchers.IO)
        {
            val activity = requireActivity()

            getImagesList(activity, false)
            getAudioFiles(activity, false)
            getVideosList(activity, false)
            getDocumentFilesList(activity, false)

            // Execute methods sequentially
            getHiddenPhotos(activity, true, false).await()
            getHiddenVideos(activity, true, false).await()
            getHiddenAudios(activity, true, false).await()
            getHiddenDocumentFiles(activity, true, false).await()


        }
        clickListners()
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun setVaultListRecyclerView(
        fragmentActivity: FragmentActivity,
        hideFolderData: FolderData,
        type: String
    )
    {

        Handler(Looper.getMainLooper()).post {
            //code that runs in main


       // lifecycleScope.launch(Dispatchers.IO){

        /*
                requireActivity().runOnUiThread{
                adapter = VaultListAdapter(fragmentActivity, hideFolderData,type)
                binding.rvVaultDataList.adapter = adapter
                adapter!!.setOnItemClickListener(this)}



        */


        if (hideFolderData.folders.size > 0) {
            adapter = VaultListAdapter(fragmentActivity, hideFolderData, type)
            binding.rvVaultDataList.adapter = adapter
            adapter!!.setOnItemClickListener(this)
            binding.rlNoDataView.gone()
            binding.rvVaultDataList.visible()
        }
        else {

            when (type) {
                PHOTO_TYPE -> {
                    binding.tvNoVaultData.text =
                        fragmentActivity.resources.getString(R.string.msg_no_photo_in_vau)
                    Glide.with(fragmentActivity).load(R.drawable.no_photo)
                        .into(binding.ivNoVaultData)

                }

                VIDEO_TYPE -> {
                    binding.tvNoVaultData.text =
                        fragmentActivity.resources.getString(R.string.msg_no_video_in_vau)
                    Glide.with(fragmentActivity).load(R.drawable.no_video)
                        .into(binding.ivNoVaultData)

                }

                AUDIO_TYPE -> {
                    binding.tvNoVaultData.text =
                        fragmentActivity.resources.getString(R.string.msg_no_audio_in_vau)
                    Glide.with(fragmentActivity).load(R.drawable.ic_audio_file)
                        .into(binding.ivNoVaultData)
                }

                FILE_TYPE -> {
                    binding.tvNoVaultData.text =
                        fragmentActivity.resources.getString(R.string.msg_no_file_in_vau)
                    Glide.with(fragmentActivity).load(R.drawable.ic_file_folder)
                        .into(binding.ivNoVaultData)

                }

                ALL_FILE_TYPE -> {
                    binding.tvNoVaultData.text =
                        fragmentActivity.resources.getString(R.string.msg_no_file_in_vau)
                    Glide.with(fragmentActivity).load(R.drawable.ic_file_folder)
                        .into(binding.ivNoVaultData)
                }

            }

            binding.rlNoDataView.visible()
            binding.rvVaultDataList.gone()
        }
        }



    }

    private fun clickListners() {
//        binding.llAllLbl.setOnClickListener {
//            catAllSelected(requireActivity())
//            setVaultListRecyclerView(requireActivity(), cHideAllFolderData, ALL_FILE_TYPE)
//        }

        binding.llAudioLbl.setOnClickListener {
            catAudioSelected(requireActivity())
         //   if (mIsGrantAudiosPermission()) {
                lifecycleScope.launch(Dispatchers.IO) {
                    getHiddenAudios(requireActivity(), false, true)
          //      }
            }
        }

        binding.llPhotoLbl.setOnClickListener {
            catPhotoSelected(requireActivity())
          //  if (mIsGrantImagesPermission()) {
                lifecycleScope.launch(Dispatchers.IO) {
                    getHiddenPhotos(requireActivity(), false, true)
             //   }
            }

        }

        binding.llVideoLbl.setOnClickListener {
            catVideoSelected(requireActivity())
           // if (mIsGrantVideosPermission()) {
                lifecycleScope.launch(Dispatchers.IO) {
                    getHiddenVideos(requireActivity(), false, true)
           //     }
            }
        }

        binding.llFileLbl.setOnClickListener {
            catFileSelected(requireActivity())
          //  if (mIsGrantFilesPermission()) {
                lifecycleScope.launch(Dispatchers.IO) {
                    getHiddenDocumentFiles(requireActivity(), false, true)
                }
           // }
        }

        binding.llPhotoVector.setOnClickListener {
            startActivityWithFolders(PHOTO_TYPE, false)
        }
        binding.llVideoVector.setOnClickListener {
            startActivityWithFolders(VIDEO_TYPE, false)
        }
        binding.llAudioVector.setOnClickListener {
            startActivityWithFolders(AUDIO_TYPE, false)
        }
        binding.llFileVector.setOnClickListener {
            startActivityWithFolders(FILE_TYPE, false)
        }
        binding.tvMore.setOnClickListener {

            if (SELECTED_VAULT_CAT == "All") {
                getAllHidenFilesData()

                startActivityWithFolders(VAULT_ALL_TYPE, true)
            }
            if (SELECTED_VAULT_CAT == "Photo") {
                startActivityWithFolders(VAULT_PHOTO_TYPE, true)
            }
            if (SELECTED_VAULT_CAT == "Video") {
                startActivityWithFolders(VAULT_VIDEO_TYPE, true)
            }
            if (SELECTED_VAULT_CAT == "Audio") {
                startActivityWithFolders(VAULT_AUDIO_TYPE, true)
            }
            if (SELECTED_VAULT_CAT == "File") {
                startActivityWithFolders(VAULT_FILE_TYPE, true)
            }
        }
    }

    private fun getAllHidenFilesData() {

        Log.d("++++++", cHideFileFolderData.folders.size.toString())
    }

    private fun handleImagePermissionsGranted() {
        lifecycleScope.launch(Dispatchers.IO) {
            getHiddenPhotos(requireActivity(), false, true)
        }
    }

    private fun handleVideoPermissionsGranted() {
        lifecycleScope.launch(Dispatchers.IO) {
            getHiddenVideos(requireActivity(), false, true)
        }
    }

    private fun handleAudioPermissionsGranted() {
        lifecycleScope.launch(Dispatchers.IO) {
            getHiddenAudios(requireActivity(), false, true)
        }
    }

    private fun handleFilePermissionsGranted() {
        lifecycleScope.launch(Dispatchers.IO) {
            getHiddenDocumentFiles(requireActivity(), false, true)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_CODE_ASK_IMAGE_PERMISSIONS -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    handleImagePermissionsGranted()
                } else {
                    // Handle permission denied
                }
            }

            REQUEST_CODE_ASK_VIDEO_PERMISSIONS -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    handleVideoPermissionsGranted()
                } else {
                    // Handle permission denied
                }
            }

            REQUEST_CODE_ASK_AUDIO_PERMISSIONS -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    handleAudioPermissionsGranted()
                } else {
                    // Handle permission denied
                }
            }

            REQUEST_CODE_ASK_FILE_PERMISSIONS -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    handleFilePermissionsGranted()
                } else {
                    // Handle permission denied
                }
            }

            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    private fun startActivityWithFolders(type: String, fromVault: Boolean) {
        startActivity(
            Intent(
                requireActivity(),
                FolderListActivity::class.java
            ).putExtra(TYPE, type).putExtra(IS_FROM_VAULT, fromVault)
        )
    }


    override fun onFolderItemClick(position: Int, folder: String) {
    }

    override fun onVaultItemClick(
        position: Int,
        folder: String,
        type: String,
        imagesByFolder: MutableMap<String, MutableList<MediaFile>>
    ) {

        if (type == PHOTO_TYPE) {

            itemImageFolderClickList = imagesByFolder[folder]

        }
        if (type == VIDEO_TYPE) {
            itemVideoFolderClickList = imagesByFolder[folder]

        }
        if (type == AUDIO_TYPE) {
            itemAudioFolderClickList = imagesByFolder[folder]

        }
        if (type == FILE_TYPE) {
            itemFileFolderClickList = imagesByFolder[folder]

        }
        itemFolderClickList= imagesByFolder[folder]

        Log.d(TAG, "onVaultItemClick----Folder--->${folder}")
        Log.d(TAG, "onVaultItemClick----FolderSize--->${imagesByFolder[folder]!!.size}")
        if (imagesByFolder[folder]!!.isNotEmpty()) {
            val intent = Intent(requireActivity(), VaultFileListActivity::class.java)
            intent.putExtra(TYPE, type)
            intent.putExtra(IS_FROM_VAULT, true)
            startActivity(intent)
        } else {
            Log.d(TAG, "onVaultItemClick----No Images in Folder")
        }

    }

    fun getAllFiles(requireActivity: FragmentActivity) {
        allFolderData = FolderData()
        var totalFileCount = 0
        val projection = arrayOf(
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.DATE_ADDED,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.MIME_TYPE
        )
        val orderBy = MediaStore.Files.FileColumns.DATE_ADDED + " DESC"
        // MIME types list
        val mimeTypes = arrayOf(
            "doc",
            "docm",
            "docx",
            "dot",
            "dotm",
            "dotx",
            "oxps",
            "pdf",
            "pot",
            "potm",
            "potx",
            "pps",
            "ppsm",
            "ppsx",
            "ppt",
            "pptm",
            "pptx",
            "xls",
            "xlsm",
            "xlsx",
            "xlt",
            "xltm",
            "xltx",
            "xps",
            "dat",
            "eml",
            "emlx",
            "msg",
            "oft",
            "conf",
            "cfg",
            "csv",
            "html",
            "xhtml",
            "htm",
            "xml",
            "json",
            "txt",
            "text",
            "log",
            "odt",
            "rtf",
            "odp",
            "ods",
            "pages",
            "key",
            "numbers",
            "epub",
            "psd",
            "ai",
            "indd",
            // Image types
            "jpg",
            "jpeg",
            "png",
            "gif",
            "bmp",
            "webp",
            "heic",

            // Video types
            "mp4",
            "mkv",
            "avi",
            "mov",
            "wmv",
            "flv",
            "webm",
            "3gp",

            // Audio types
            "mp3",
            "wav",
            "ogg",
            "aac",
            "m4a",
            "flac",
            "wma"
        )

        val selection = StringBuilder().apply {
            append(MediaStore.Files.FileColumns.MIME_TYPE)
            append(" IN (")
            append(mimeTypes.joinToString(",") { "?" })
            append(")")
        }.toString()

        val selectionArgs = mimeTypes.mapNotNull {
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(it)
        }.toTypedArray()
        val collection: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Files.getContentUri("external")
        }

        requireActivity.contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            orderBy
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val columnName = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val columnPath = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)
                val columnDateAdded = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATE_ADDED)
                do {
                    val name = cursor.getString(columnName)
                    val path = cursor.getString(columnPath)
                    val dateAdded = formatDate(cursor.getLong(columnDateAdded))

                    // Extracting folder  from the file path
                    val folderName = path.substringBeforeLast("/").substringAfterLast("/")
                    val document = MediaFile(name, path, dateAdded, false, folderName, "file")

                    // Skip hidden folders (folders that start with a dot)
                    if (!folderName.startsWith(".")) {
                        totalFileCount++
                        // Storing unique folders
                        if (!allFolderData.folders.contains(folderName)) {
                            allFolderData.folders.add(folderName)
                        }

                        // Grouping by folder
                        val folderImages =
                            allFolderData.imagesByFolder.getOrPut(folderName) { mutableListOf() }
                        folderImages.add(document)

                        Log.d(
                            TAG,
                            "AllFile+++++++NAME:----$name\n PATH:---- $path\n DATE:---- $dateAdded\nFOLDER:---- $folderName\n"
                        )
                    }


                } while (cursor.moveToNext())
            }

        }

        allFolderData.count = totalFileCount

        // Remove folders without files from the list
        allFolderData.imagesByFolder =
            allFolderData.imagesByFolder.filterValues { it.isNotEmpty() }.toMutableMap()
        allFolderData.folders.clear()
        allFolderData.folders.addAll(allFolderData.imagesByFolder.keys)

        Log.w(TAG, "AllFile+++++++Size()----: ${allFolderData.imagesByFolder.size}")
        Log.w(TAG, "AllFile+++++++Count()----: ${allFolderData.count}")


        if (allFolderData.folders.size > 0) {
            binding.rlNoDataView.gone()
            binding.rvVaultDataList.visible()
        } else {
            binding.tvNoVaultData.text = resources.getString(R.string.msg_no_file_in_vau)
            binding.rlNoDataView.visible()
            binding.rvVaultDataList.gone()
        }

    }

    companion object {
        fun newInstance() = VaultFragment()
        var TAG = "VaultFragment++++"

        lateinit var binding: FragmentVaultBinding

        var adapter: VaultListAdapter? = null

        private val REQUEST_CODE_ASK_IMAGE_PERMISSIONS = 135
        private val REQUEST_CODE_ASK_VIDEO_PERMISSIONS = 1354
        private val REQUEST_CODE_ASK_AUDIO_PERMISSIONS = 13546
        private val REQUEST_CODE_ASK_FILE_PERMISSIONS = 13547

        var cHideImageFolderData = FolderData()
        var cHideVideoFolderData = FolderData()
        var cHideAudioFolderData = FolderData()
        var cHideFileFolderData = FolderData()

        var imageFolderData = FolderData()
        var videoFolderData = FolderData()
        var audioFolderData = FolderData()
        var documentFolderData = FolderData()
        var allFolderData = FolderData()

        var itemImageFolderClickList: MutableList<MediaFile>? = mutableListOf()
        var itemVideoFolderClickList: MutableList<MediaFile>? = mutableListOf()
        var itemFileFolderClickList: MutableList<MediaFile>? = mutableListOf()
        var itemAudioFolderClickList: MutableList<MediaFile>? = mutableListOf()
        var itemFolderClickList: MutableList<MediaFile>? = mutableListOf()

        // Define a coroutine scope for the fragment
        val fragmentScope = CoroutineScope(Dispatchers.Main)

        // Define a custom dispatcher for IO operations
        val ioDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()

        suspend fun getImagesList(requireActivity: FragmentActivity, isFromClick: Boolean) {
            withContext(ioDispatcher) {
                imageFolderData = FolderData()
                var totalImagesCount = 0 // Initialize total image count

                val projection = arrayOf(
                    MediaStore.Images.Media.DATA,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_MODIFIED,
                    MediaStore.Images.Media.SIZE
                )

                val orderBy = MediaStore.Images.ImageColumns.DATE_MODIFIED + " DESC"
                val cursor = requireActivity.contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    null,
                    null,
                    orderBy
                )

                if (cursor != null) {
                    for (i in 0 until cursor.count) {
                        cursor.moveToPosition(i)
                        val photosPath =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                        val photosName =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME))
                        val photosDate =
                            formatDate(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)))

                        val folderName = photosPath.substringBeforeLast("/").substringAfterLast("/")

                        Log.d(
                            TAG,
                            "ImagesFile+++++++NAME:----$photosName\n PATH:---- $photosPath\n DATE:---- $photosDate\n FOLDER:---- $folderName"
                        )

                        val imageFile = MediaFile(
                            photosPath,
                            photosName,
                            photosDate,
                            false,
                            folderName,
                            "photo"
                        )
                        totalImagesCount++


                        // Skip hidden folders (folders that start with a dot) and folders with zero size
                        if (folderName.startsWith(".") ||
                            imageFolderData.folders.contains(folderName)
                            && imageFolderData.imagesByFolder[folderName]?.size == 0
                        ) {
                            continue
                        }

                        // Storing unique folders
                        if (!imageFolderData.folders.contains(folderName)) {
                            imageFolderData.folders.add(folderName)
                            Log.d(
                                TAG, "ImagesfolderPathM+++++++Folder:----$folderName"
                            )
                        }
                        // Grouping images by folder
                        val folderImages =
                            imageFolderData.imagesByFolder.getOrPut(folderName) { mutableListOf() }
                        folderImages.add(imageFile)


                    }
                    cursor.close()
                }

                // Remove folders without files from the list
                imageFolderData.imagesByFolder =
                    imageFolderData.imagesByFolder.filterValues { it.isNotEmpty() }.toMutableMap()
                imageFolderData.folders.clear()
                imageFolderData.folders.addAll(imageFolderData.imagesByFolder.keys)
                imageFolderData.count = totalImagesCount

                Log.w(TAG, "ImagesFile+++++++Size()----: " + imageFolderData.imagesByFolder.size)
                Log.w(TAG, "ImagesFile+++++++count()----: ${imageFolderData.count}")

                requireActivity.runOnUiThread {
                    // Update UI on the main thread
                    binding.tvPhotoCount.text = totalImagesCount.toString()
                }

            }
        }

        suspend fun getVideosList(requireActivity: FragmentActivity, isFromClick: Boolean) {
            withContext(Dispatchers.IO) {
                videoFolderData = FolderData()
                var totalVideosCount = 0 // Initialize total video count
                val projection = arrayOf(
                    MediaStore.Video.Media.DATA,
                    MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.DATE_ADDED,
                )

                val cursor = requireActivity.contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, null
                )
                if (cursor != null) {
                    for (i in 0 until cursor.count) {
                        cursor.moveToPosition(i)
                        val videopath =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA))
                        val videoName =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                        val videoDate =
                            formatDate(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)))


                        val folderName = videopath.substringBeforeLast("/").substringAfterLast("/")
                        val videoFiles =
                            MediaFile(videopath, videoName, videoDate, false, folderName, "video")
                        Log.d(
                            TAG,
                            "GalleryVideo+++++++NAME:----$videoName\n PATH:---- $videopath\n DATE:---- $videoDate\n" + " FOLDER:---- $folderName"
                        )

                        // Extracting folder from the file path
                        totalVideosCount++

                        // Skip hidden folders (folders that start with a dot) and folders with zero size
                        if (folderName.startsWith(".") ||
                            videoFolderData.folders.contains(folderName) &&
                            videoFolderData.imagesByFolder[folderName]?.size == 0
                        ) {
                            continue
                        }


                        // Storing unique folders
                        if (!videoFolderData.folders.contains(folderName)) {
                            videoFolderData.folders.add(folderName)
                            Log.d(
                                TAG, "VideofolderPathM+++++++Folder:----$folderName"
                            )
                        }

                        // Grouping images by folder
                        val videoFolder =
                            videoFolderData.imagesByFolder.getOrPut(folderName) { mutableListOf() }
                        videoFolder.add(videoFiles)

                    }
                }
                cursor?.close()

                // Remove folders without files from the list
                videoFolderData.imagesByFolder =
                    videoFolderData.imagesByFolder.filterValues { it.isNotEmpty() }.toMutableMap()
                videoFolderData.folders.clear()
                videoFolderData.folders.addAll(videoFolderData.imagesByFolder.keys)


                videoFolderData.count = totalVideosCount


                Log.w(TAG, "GalleryVideo+++++++Size()----: " + videoFolderData.imagesByFolder.size)
                Log.w(TAG, "GalleryVideo+++++++count()----: " + videoFolderData.count)

                requireActivity.runOnUiThread {
                    // Update UI on the main thread
                    binding.tvVideoCount.text = videoFolderData.count.toString()

                }

            }
        }

        suspend fun getAudioFiles(requireActivity: FragmentActivity, isFromClick: Boolean) {
            return withContext(Dispatchers.IO) {
                audioFolderData = FolderData()
                var totalAudioCount = 0 // Initialize total Audio count

                val projection = arrayOf(
                    MediaStore.Audio.Media.DATA,
                    MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.DATE_ADDED
                )
                val orderBy = MediaStore.Audio.Media.DATE_ADDED + " DESC"

                val cursor = requireActivity.contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, null, null, orderBy
                )


                if (cursor != null) {
                    for (i in 0 until cursor.count) {
                        cursor.moveToPosition(i)


                        val audioPath =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA))
                        val audioName =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME))
                        val audioDate =
                            formatDate(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)))

                        val folderName = audioPath.substringBeforeLast("/").substringAfterLast("/")
                        val audioFiles =
                            MediaFile(audioPath, audioName, audioDate, false, folderName, "audio")

                        Log.d(
                            TAG,
                            "Audio+++++++NAME:----$audioName\n PATH:---- $audioPath\n DATE:---- $audioDate\n" + " FOLDER:---- $folderName"
                        )

                        // Extracting folder from the file path
                        totalAudioCount++

                        // Skip hidden folders (folders that start with a dot) and folders with zero size
                        if (folderName.startsWith(".") ||
                            audioFolderData.folders.contains(folderName) &&
                            audioFolderData.imagesByFolder[folderName]?.size == 0
                        ) {
                            continue
                        }


                        // Storing unique folders
                        if (!audioFolderData.folders.contains(folderName)) {
                            audioFolderData.folders.add(folderName)
                            Log.d(
                                TAG, "AudiofolderPathM+++++++Folder:----$folderName"
                            )
                        }

                        // Grouping images by folder
                        val audioFolder =
                            audioFolderData.imagesByFolder.getOrPut(folderName) { mutableListOf() }
                        audioFolder.add(audioFiles)

                    }
                }
                cursor?.close()


                // Remove folders without files from the list
                audioFolderData.imagesByFolder =
                    audioFolderData.imagesByFolder.filterValues { it.isNotEmpty() }.toMutableMap()
                audioFolderData.folders.clear()
                audioFolderData.folders.addAll(audioFolderData.imagesByFolder.keys)


                audioFolderData.count = totalAudioCount


                Log.w(TAG, "AudioFile+++++++Size()----: ${audioFolderData.imagesByFolder.size}")
                Log.w(TAG, "AudioFile+++++++count()----: ${audioFolderData.count}")


                requireActivity.runOnUiThread {
                    // Update UI on the main thread
                    binding.tvAudioCount.text = audioFolderData.count.toString()
                }

            }
        }

        suspend fun getDocumentFilesList(requireActivity: FragmentActivity, isFromClick: Boolean) {
            return withContext(Dispatchers.IO) {
                documentFolderData = FolderData()
                var totalDocumentCount = 0

                val projection = arrayOf(
                    MediaStore.Files.FileColumns.DISPLAY_NAME,
                    MediaStore.Files.FileColumns.DATE_ADDED,
                    MediaStore.Files.FileColumns.DATA
                )

                val orderBy = MediaStore.Files.FileColumns.DATE_ADDED + " DESC"

                val mimeTypes = arrayOf(
                    "doc",
                    "docm",
                    "docx",
                    "dot",
                    "dotm",
                    "dotx",
                    "oxps",
                    "pdf",
                    "pot",
                    "potm",
                    "potx",
                    "pps",
                    "ppsm",
                    "ppsx",
                    "ppt",
                    "pptm",
                    "pptx",
                    "xls",
                    "xlsm",
                    "xlsx",
                    "xlt",
                    "xltm",
                    "xltx",
                    "xps",
                    "dat",
                    "eml",
                    "emlx",
                    "msg",
                    "oft",
                    "conf",
                    "cfg",
                    "csv",
                    "html",
                    "xhtml",
                    "htm",
                    "xml",
                    "json",
                    "txt",
                    "text",
                    "log",
                    "odt",
                    "rtf",
                    "odp",
                    "ods",
                    "pages",
                    "key",
                    "numbers",
                    "epub",
                    "psd",
                    "ai",
                    "indd"
                )

                val selection = StringBuilder().apply {
                    append(MediaStore.Files.FileColumns.MIME_TYPE)
                    append(" IN (")
                    append(mimeTypes.joinToString(",") { "?" })
                    append(")")
                }.toString()

                val selectionArgs = mimeTypes.mapNotNull {
                    MimeTypeMap.getSingleton().getMimeTypeFromExtension(it)
                }.toTypedArray()

                val collection: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
                } else {
                    MediaStore.Files.getContentUri("external")
                }

                requireActivity.contentResolver.query(
                    collection, projection, selection, selectionArgs, orderBy
                )?.use { cursor ->
                    while (cursor.moveToNext()) {
                        val name =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME))
                        val path =
                            cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA))
                        val dateAdded =
                            formatDate(cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED)))
                        val folderName = path.substringBeforeLast("/").substringAfterLast("/")
                        val document = MediaFile(name, path, dateAdded, false, folderName, "file")

                        //  if (!folderName.startsWith(".")) {
                        if (!folderName.startsWith(".") && !path.contains("/.")) {

                            if (!documentFolderData.folders.contains(folderName)) {
                                documentFolderData.folders.add(folderName)
                            }

                            val documentFolder =
                                documentFolderData.imagesByFolder.getOrPut(folderName) { mutableListOf() }
                            documentFolder.add(document)


                            Log.d(
                                TAG,
                                "DocumentFile+++++++NAME:----$name\n PATH:---- $path\n DATE:---- $dateAdded\n" + " FOLDER:---- $folderName"
                            )
                            totalDocumentCount++

                        }
                    }
                }


                // Remove folders without files from the list
                documentFolderData.imagesByFolder =
                    documentFolderData.imagesByFolder.filterValues { it.isNotEmpty() }
                        .toMutableMap()
                documentFolderData.folders.clear()
                documentFolderData.folders.addAll(documentFolderData.imagesByFolder.keys)
                documentFolderData.count = totalDocumentCount

                Log.w(
                    TAG,
                    "DocumentFile+++++++Size()----: ${documentFolderData.imagesByFolder.size}"
                )
                Log.w(TAG, "DocumentFile+++++++Count()----: ${documentFolderData.count}")

                requireActivity.runOnUiThread {
                    // Update UI on the main thread
                    binding.tvFileCount.text = documentFolderData.count.toString()

                }


            }
        }

        suspend fun getHiddenPhotos(
            fragmentActivity: FragmentActivity,
            isInitial: Boolean,
            isPhotoTabClick: Boolean
        ): Deferred<Unit> = coroutineScope {
            async(Dispatchers.IO) {
                val hiddenFolder = File(PHOTO_SDCARD_PATH_ABOVE_Q)
                if (!hiddenFolder.exists()) {
                    hiddenFolder.mkdirs()
                }

                val folderList = hiddenFolder.listFiles()
                if (folderList != null) {

                    val hideImageFolderData = FolderData()
                    var totalHideImagesCount = 0

                    for (subfile in folderList) {
                        val file = File(subfile.toString())
                        //  if (file.exists())
                        if (file.exists() && file.isDirectory) {
                            for (files in file.listFiles()!!) {
                                val filerr = File(files.toString())

                                val photosName = filerr.name
                                val photosPath = filerr.absolutePath
                                val photosDate = formatDate(filerr.lastModified() / 1000)
                                val folderName = photosPath.toString().substringBeforeLast("/")
                                    .substringAfterLast("/")

                                val imageFile = MediaFile(
                                    photosPath.toString(),
                                    photosName,
                                    photosDate,
                                    false,
                                    folderName,
                                    "photo"
                                )
                                totalHideImagesCount++

                                if (!hideImageFolderData.folders.contains(folderName)) {
                                    hideImageFolderData.folders.add(folderName)
                                    Log.d(
                                        TAG, "hideImageFolderDataPathM+++++++Folder:----$folderName"
                                    )
                                }

                                val folderImages =
                                    hideImageFolderData.imagesByFolder.getOrPut(folderName) { mutableListOf() }
                                folderImages.add(imageFile)
                            }
                        }
                    }

                    hideImageFolderData.imagesByFolder =
                        hideImageFolderData.imagesByFolder.filterValues { it.isNotEmpty() }
                            .toMutableMap()
                    hideImageFolderData.folders.clear()
                    hideImageFolderData.folders.addAll(hideImageFolderData.imagesByFolder.keys)
                    hideImageFolderData.count = totalHideImagesCount

                    Log.w(
                        TAG,
                        "hideImageFolderData+++++++Size()----: " + hideImageFolderData.imagesByFolder.size
                    )
                    Log.w(
                        TAG,
                        "hideImageFolderData+++++++count()----: ${hideImageFolderData.count}"
                    )


                    fragmentScope.launch {
                        hideImageFolderData.reverse()//reverse data to get Recent on Top

                        cHideImageFolderData = hideImageFolderData

                        if (!isInitial) {
                            updateUI(fragmentActivity, hideImageFolderData, PHOTO_TYPE)
                            if (!isPhotoTabClick) {

                            }

                        }
                    }



                }
            }
        }

        suspend fun getHiddenVideos(
            fragmentActivity: FragmentActivity,
            isInitial: Boolean,
            isVideoTabClick: Boolean
        ): Deferred<Unit> = coroutineScope {
            async(Dispatchers.IO) {
                val hiddenFolder = File(VIDEO_SDCARD_PATH_ABOVE_Q)
                if (!hiddenFolder.exists()) {
                    hiddenFolder.mkdirs()
                }

                val folderList = hiddenFolder.listFiles()
                if (folderList != null) {

                    val hideVideoFolderData = FolderData()
                    var totalHideVideosCount = 0

                    for (subfile in folderList) {
                        val file = File(subfile.toString())
                        //  if (file.exists())
                        if (file.exists() && file.isDirectory) {
                            for (files in file.listFiles()!!) {
                                val filerr = File(files.toString())

                                val photosName = filerr.name
                                val photosPath = filerr.absolutePath
                                val photosDate = formatDate(filerr.lastModified() / 1000)
                                val folderName = photosPath.toString().substringBeforeLast("/")
                                    .substringAfterLast("/")

                                val imageFile = MediaFile(
                                    photosPath.toString(),
                                    photosName,
                                    photosDate,
                                    false,
                                    folderName,
                                    "video"
                                )
                                totalHideVideosCount++

                                if (!hideVideoFolderData.folders.contains(folderName)) {
                                    hideVideoFolderData.folders.add(folderName)
                                    Log.d(
                                        TAG, "hideVideoFolderData+++++++Folder:----$folderName"
                                    )
                                }

                                val folderImages =
                                    hideVideoFolderData.imagesByFolder.getOrPut(folderName) { mutableListOf() }
                                folderImages.add(imageFile)
                            }
                        }
                    }

                    hideVideoFolderData.imagesByFolder = hideVideoFolderData.imagesByFolder.filterValues { it.isNotEmpty() }.toMutableMap()
                    hideVideoFolderData.folders.clear()
                    hideVideoFolderData.folders.addAll(hideVideoFolderData.imagesByFolder.keys)
                    hideVideoFolderData.count = totalHideVideosCount

                    Log.w(
                        TAG,
                        "hideVideoFolderData+++++++Size()----: " + hideVideoFolderData.imagesByFolder.size
                    )
                    Log.w(
                        TAG,
                        "hideVideoFolderData+++++++count()----: ${hideVideoFolderData.count}"
                    )

                    fragmentScope.launch {
                        hideVideoFolderData.reverse()//reverse data to get Recent on Top
                        cHideVideoFolderData = hideVideoFolderData
                        if (!isInitial) {
                            updateUI(fragmentActivity, hideVideoFolderData, VIDEO_TYPE)
                            if (!isVideoTabClick) { }

                        }
                    }
                }
            }
        }

        suspend fun getHiddenAudios(
            fragmentActivity: FragmentActivity,
            isInitial: Boolean,
            isAudioTabClick: Boolean
        ): Deferred<Unit> = coroutineScope {
            async(Dispatchers.IO) {
                val hiddenFolder = File(AUDIO_SDCARD_PATH_ABOVE_Q)
                if (!hiddenFolder.exists()) {
                    hiddenFolder.mkdirs()
                }

                val folderList = hiddenFolder.listFiles()
                if (folderList != null) {

                    val hideAudioFolderData = FolderData()
                    var totalHideAudioCount = 0

                    for (subfile in folderList) {
                        val file = File(subfile.toString())
                        //  if (file.exists())
                        if (file.exists() && file.isDirectory) {
                            for (files in file.listFiles()!!) {
                                val filerr = File(files.toString())

                                val photosName = filerr.name
                                val photosPath = filerr.absolutePath
                                val photosDate = formatDate(filerr.lastModified() / 1000)
                                val folderName = photosPath.toString().substringBeforeLast("/")
                                    .substringAfterLast("/")

                                val imageFile = MediaFile(
                                    photosPath.toString(),
                                    photosName,
                                    photosDate,
                                    false,
                                    folderName, "audio"
                                )
                                totalHideAudioCount++

                                if (!hideAudioFolderData.folders.contains(folderName)) {
                                    hideAudioFolderData.folders.add(folderName)
                                    Log.d(
                                        TAG, "hideAudioFolderData+++++++Folder:----$folderName"
                                    )
                                }

                                val folderImages =
                                    hideAudioFolderData.imagesByFolder.getOrPut(folderName) { mutableListOf() }
                                folderImages.add(imageFile)
                            }
                        }
                    }

                    hideAudioFolderData.imagesByFolder =
                        hideAudioFolderData.imagesByFolder.filterValues { it.isNotEmpty() }
                            .toMutableMap()
                    hideAudioFolderData.folders.clear()
                    hideAudioFolderData.folders.addAll(hideAudioFolderData.imagesByFolder.keys)
                    hideAudioFolderData.count = totalHideAudioCount

                    Log.w(
                        TAG,
                        "hideAudioFolderData+++++++Size()----: " + hideAudioFolderData.imagesByFolder.size
                    )
                    Log.w(
                        TAG,
                        "hideAudioFolderData+++++++count()----: ${hideAudioFolderData.count}"
                    )

                    fragmentScope.launch {
                        cHideAudioFolderData.reverse()//reverse data to get Recent on Top

                        cHideAudioFolderData = hideAudioFolderData
                        if (!isInitial) {
                            updateUI(fragmentActivity, hideAudioFolderData, AUDIO_TYPE)
                            if (!isAudioTabClick) { }

                        }
                    }
                }
            }
        }

        suspend fun getHiddenDocumentFiles(
            fragmentActivity: FragmentActivity,
            isInitial: Boolean,
            isFileTabClick: Boolean
          ): Deferred<Unit> = coroutineScope {
            async(Dispatchers.IO) {
                val hiddenFolder = File(FILE_SDCARD_PATH_ABOVE_Q)
                if (!hiddenFolder.exists()) {
                    hiddenFolder.mkdirs()
                }

                val folderList = hiddenFolder.listFiles()
                if (folderList != null) {

                    val hideDocumentFolderData = FolderData()
                    var totalHideFilesCount = 0

                    for (subfile in folderList) {
                        val file = File(subfile.toString())
                        //  if (file.exists())
                        if (file.exists() && file.isDirectory) {
                            for (files in file.listFiles()!!) {
                                val filerr = File(files.toString())

                                val photosName = filerr.name
                                val photosPath = filerr.absolutePath
                                val photosDate = formatDate(filerr.lastModified() / 1000)
                                val folderName = photosPath.toString().substringBeforeLast("/")
                                    .substringAfterLast("/")

                                val imageFile = MediaFile(
                                    photosPath.toString(),
                                    photosName,
                                    photosDate,
                                    false,
                                    folderName, "file"
                                )
                                totalHideFilesCount++

                                if (!hideDocumentFolderData.folders.contains(folderName)) {
                                    hideDocumentFolderData.folders.add(folderName)
                                    Log.d(
                                        TAG, "hideFileFolderData+++++++Folder:----$folderName"
                                    )
                                }

                                val folderImages =
                                    hideDocumentFolderData.imagesByFolder.getOrPut(folderName) { mutableListOf() }
                                folderImages.add(imageFile)
                            }
                        }
                    }

                    hideDocumentFolderData.imagesByFolder = hideDocumentFolderData.imagesByFolder.filterValues { it.isNotEmpty() }.toMutableMap()
                    hideDocumentFolderData.folders.clear()
                    hideDocumentFolderData.folders.addAll(hideDocumentFolderData.imagesByFolder.keys)
                    hideDocumentFolderData.count = totalHideFilesCount

                    Log.w(
                        TAG,
                        "hideFileFolderData+++++++Size()----: " + hideDocumentFolderData.imagesByFolder.size
                    )
                    Log.w(
                        TAG,
                        "hideFileFolderData+++++++count()----: ${hideDocumentFolderData.count}"
                    )

                    fragmentScope.launch {
                        hideDocumentFolderData.reverse()//reverse data to get Recent on Top
                        cHideFileFolderData = hideDocumentFolderData
                        if (!isInitial)

                            updateUI(fragmentActivity, hideDocumentFolderData, FILE_TYPE)
                        if (!isFileTabClick) { }

                        if (isInitial) {

                            VaultFragment.newInstance().setVaultListRecyclerView(fragmentActivity, cHideImageFolderData,FILE_TYPE)
                            updateUI(fragmentActivity, cHideImageFolderData, ALL_FILE_TYPE)
                        }

                    }
                }
            }
        }


        fun formatDate(dateInMillis: Long): String {
            val dateFormat = SimpleDateFormat("dd/MM/yy hh:mm a", Locale.getDefault())
            val calendar = Calendar.getInstance()
            calendar.timeInMillis = dateInMillis
            return dateFormat.format(calendar.time)
        }

        suspend fun updateUI(
            fragmentActivity: FragmentActivity,
            hideImageFolderData: FolderData,
            type: String
        ) {
            fragmentActivity.runOnUiThread {
                if (hideImageFolderData.folders.size > 0) {
                    adapter?.addVaultData(hideImageFolderData, type)
                    adapter?.notifyDataSetChanged()
                    binding.rlNoDataView.gone()
                    binding.rvVaultDataList.visible()
                } else {

                    when (type) {
                        PHOTO_TYPE -> {
                            Log.d(TAG+"UpdateUI", "No photo data")
                            binding.tvNoVaultData.text =
                                fragmentActivity.resources.getString(R.string.msg_no_photo_in_vau)
                            Glide.with(fragmentActivity).load(R.drawable.no_photo)
                                .into(binding.ivNoVaultData)

                        }

                        VIDEO_TYPE -> {
                            Log.d(TAG+"UpdateUI", "No video data")

                            binding.tvNoVaultData.text =
                                fragmentActivity.resources.getString(R.string.msg_no_video_in_vau)
                            Glide.with(fragmentActivity).load(R.drawable.no_video)
                                .into(binding.ivNoVaultData)

                        }

                        AUDIO_TYPE -> {
                            Log.d(TAG+"UpdateUI", "No audio data")
                            binding.tvNoVaultData.text =
                                fragmentActivity.resources.getString(R.string.msg_no_audio_in_vau)
                            Glide.with(fragmentActivity).load(R.drawable.ic_audio_file)
                                .into(binding.ivNoVaultData)
                        }

                        FILE_TYPE, ALL_FILE_TYPE ->  {
                            Log.d(TAG+"UpdateUI", "No file data")
                            binding.tvNoVaultData.text = fragmentActivity.resources.getString(R.string.msg_no_file_in_vau)

                           // binding.ivNoVaultData.setImageDrawable(fragmentActivity.resources.getDrawable(R.drawable.ic_file_folder))
                           Glide.with(fragmentActivity).load(R.drawable.ic_file_folder)
                                .into(binding.ivNoVaultData)

                        }

                    }

                    binding.rlNoDataView.visible()
                    binding.rvVaultDataList.gone()
                }
            }
        }


        fun inValidateAppCatSelection(fragmentActivity: FragmentActivity) {
            fragmentActivity.runOnUiThread {
                binding.vAll.gone()
                binding.vVideo.gone()
                binding.vAudio.gone()
                binding.vPhoto.gone()
                binding.vFile.gone()
                SELECTED_VAULT_CAT = "All"
            }
        }

        fun catAllSelected(requireActivity: FragmentActivity) {
            inValidateAppCatSelection(requireActivity)
            requireActivity.runOnUiThread {
                binding.vAll.visible()
                binding.tvAllLbl.visible()
                SELECTED_VAULT_CAT = "All"
            }
        }

        fun catAudioSelected(requireActivity: FragmentActivity) {
            inValidateAppCatSelection(requireActivity)
            requireActivity.runOnUiThread {
                binding.vAudio.visible()
                binding.txtAudioLbl.visible()
                SELECTED_VAULT_CAT = "Audio"
            }
        }

        fun catPhotoSelected(requireActivity: FragmentActivity) {
            inValidateAppCatSelection(requireActivity)
            requireActivity.runOnUiThread {
                binding.vPhoto.visible()
                binding.tvPhotoLbl.visible()
                SELECTED_VAULT_CAT = "Photo"
            }
        }

        fun catVideoSelected(requireActivity: FragmentActivity) {
            inValidateAppCatSelection(requireActivity)
            requireActivity.runOnUiThread {
                binding.vVideo.visible()
                binding.tvVideoLbl.visible()
                SELECTED_VAULT_CAT = "Video"
            }
        }

        fun catFileSelected(requireActivity: FragmentActivity) {
            inValidateAppCatSelection(requireActivity)
            requireActivity.runOnUiThread {
                binding.vFile.visible()
                binding.tvFileLbl.visible()
                SELECTED_VAULT_CAT = "File"
            }
        }


        fun setInitVaultRecyclerView(
            fragmentActivity: FragmentActivity,
            hideFolderData: FolderData,
            type: String
        ) {

            fragmentActivity.runOnUiThread{
            if (hideFolderData.folders.size > 0) {

                binding.rlNoDataView.gone()
                binding.rvVaultDataList.visible()
            } else {

                when (type) {
                    PHOTO_TYPE -> {
                        binding.tvNoVaultData.text =
                            fragmentActivity.resources.getString(R.string.msg_no_photo_in_vau)
                        Glide.with(fragmentActivity).load(R.drawable.no_photo)
                            .into(binding.ivNoVaultData)

                    }

                    VIDEO_TYPE -> {
                        binding.tvNoVaultData.text =
                            fragmentActivity.resources.getString(R.string.msg_no_video_in_vau)
                        Glide.with(fragmentActivity).load(R.drawable.no_video)
                            .into(binding.ivNoVaultData)

                    }

                    AUDIO_TYPE -> {
                        binding.tvNoVaultData.text =
                            fragmentActivity.resources.getString(R.string.msg_no_audio_in_vau)
                        Glide.with(fragmentActivity).load(R.drawable.ic_audio_file)
                            .into(binding.ivNoVaultData)
                    }

                    FILE_TYPE -> {
                        binding.tvNoVaultData.text =
                            fragmentActivity.resources.getString(R.string.msg_no_file_in_vau)
                        Glide.with(fragmentActivity).load(R.drawable.ic_file_folder)
                            .into(binding.ivNoVaultData)

                    }

                    ALL_FILE_TYPE -> {
                        binding.tvNoVaultData.text =
                            fragmentActivity.resources.getString(R.string.msg_no_file_in_vau)
                        Glide.with(fragmentActivity).load(R.drawable.ic_file_folder)
                            .into(binding.ivNoVaultData)
                    }

                }

                binding.rlNoDataView.visible()
                binding.rvVaultDataList.gone()
            }}

    }

}

}