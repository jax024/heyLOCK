package com.applock.lock.apps.fingerprint.password.navigation.vault

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.FileUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.utils.AUDIO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VIDEO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.loadAudioThumbnail
import com.bumptech.glide.Glide


class VaultFileListAdapter(val ctx: Context, var filesData: ArrayList<MediaFile>, var type: String) :
    RecyclerView.Adapter<VaultFileListAdapter.ViewHolder>() {
    private var itemClickListener: OnItemClickListener? = null
    private var mSelected: HashSet<Int>? = null
    init {
        mSelected = HashSet()
    }

    interface OnItemClickListener {
        fun onFileItemClick(position: Int, mediaFile: MediaFile)
        fun onItemLongClick(view: View?, position: Int, mediaFile: MediaFile): Boolean
        fun onSelectionCountChanged(selectedCount: Int)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.itemClickListener = listener
    }

    fun toggleSelection(position: Int): Int {
        if (mSelected!!.contains(position)) {
            mSelected!!.remove(position)
        } else {
            mSelected!!.add(position)
        }
        notifyItemChanged(position)
        return mSelected!!.size
    }
    // Add method to get selected items
    fun getSelectedItems(): ArrayList<MediaFile> {
        val selectedFiles = ArrayList<MediaFile>()
        for (position in mSelected!!) {
            selectedFiles.add(filesData[position])
        }
        return selectedFiles
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_file, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(position, filesData[position])
    }

    override fun getItemCount(): Int {
        return filesData.size
    }

    fun select(pos: Int, selected: Boolean) {
        if (selected) mSelected!!.add(pos) else mSelected!!.remove(pos)
        notifyItemChanged(pos)
    }
    fun getAudioThumbnail(audioPath: String?): Bitmap? {
        var thumbnail: Bitmap? = null
        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(audioPath)
            val data = retriever.embeddedPicture
            if (data != null) {
                thumbnail = BitmapFactory.decodeByteArray(data, 0, data.size)
            }
            retriever.release()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
        return thumbnail
    }

    fun getVideoDuration(videoPath: String?): Long {
        var duration: Long = 0
        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(videoPath)
            val durationStr =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            duration = durationStr!!.toLong()
            retriever.release()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
        return duration
    }


    fun selectRange(start: Int, end: Int, selected: Boolean) {
        for (i in start..end) {
            if (selected) mSelected!!.add(i) else mSelected!!.remove(i)
        }
        notifyItemRangeChanged(start, end - start + 1)
    }

    fun deselectAll() {
        mSelected!!.clear()
        notifyDataSetChanged()
    }

    fun selectAll() {
        for (i in 0 until filesData.size)
        {
            mSelected!!.add(i)
        notifyItemChanged(i)}

    }

    fun getCountSelected(): Int {
        return mSelected!!.size
    }

    fun getSelection(): HashSet<Int> {
        return mSelected!!
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        private val ivFileThumb: ImageView = itemView.findViewById(R.id.ivFileThumb)
        private val ivSelect: ImageView = itemView.findViewById(R.id.ivSelect)
        fun bind(position: Int, mediaFile: MediaFile)
        {

            if(mediaFile.type=="photo"){Glide.with(ctx).load(mediaFile.filePath).into(ivFileThumb)}
            if(mediaFile.type=="video"){Glide.with(ctx).load(mediaFile.filePath).into(ivFileThumb)

            Log.d("shdg","duration-----"+getVideoDuration(mediaFile.filePath))


            }
            if(mediaFile.type=="audio"){
              //  Glide.with(ctx).load(R.drawable.ic_audio_folder).into(ivFileThumb)
                Glide.with(ctx).load(getAudioThumbnail(mediaFile.filePath)).into(ivFileThumb)

}

            if(mediaFile.type=="file"){Glide.with(ctx).load(R.drawable.ic_file_folder).into(ivFileThumb)}

        /*
            when (type) {
                PHOTO_TYPE -> {Glide.with(ctx).load(mediaFile.filePath).into(ivFileThumb)}
                VIDEO_TYPE -> {Glide.with(ctx).load(mediaFile.filePath).into(ivFileThumb)}
                AUDIO_TYPE -> {Glide.with(ctx).load(R.drawable.ic_audio_file).into(ivFileThumb)}
                FILE_TYPE -> {Glide.with(ctx).load(R.drawable.ic_file_item).into(ivFileThumb)}
                }*/

         //   Glide.with(ctx).load(mediaFile.filePath).into(ivFileThumb)
            itemView.setOnClickListener {
                if (mSelected!!.isEmpty()) {
                    itemClickListener?.onFileItemClick(position, mediaFile)
                } else {
                    toggleSelection(position)
                    updateItemState(position)
                }
            }
            itemView.setOnLongClickListener{
                itemClickListener?.onItemLongClick(it,position, mediaFile)
                return@setOnLongClickListener false
            }
            updateItemState(position)
        }

        private fun updateItemState(position: Int)
        {
            if(mSelected?.size!!>0) {
                if ( mSelected!!.contains(position)) {
                    ivSelect.setImageResource(R.drawable.img_file_select)
                } else {
                    ivSelect.setImageResource(R.drawable.img_file_unselect)
                }
            }else{
                ivSelect.setImageResource(R.drawable.img_file_unselect)
            }
            updateHideButtonText()
        }

        // Add a method to update Hide button text
        private fun updateHideButtonText() {
            itemClickListener?.onSelectionCountChanged(getCountSelected())
        }
    }
}
