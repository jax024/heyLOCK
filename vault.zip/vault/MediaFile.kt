package com.applock.lock.apps.fingerprint.password.navigation.vault

import android.os.Parcel
import android.os.Parcelable
import java.io.Serializable

class MediaFile(
    var filePath: String,
    var fileName: String,
    var fileDate: String,
    var isSelected: Boolean,
    var folderName: String,
    var type: String


) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readByte() != 0.toByte(),
        parcel.readString() ?: "",
        parcel.readString() ?: ""
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(filePath)
        parcel.writeString(fileName)
        parcel.writeString(fileDate)
        parcel.writeByte(if (isSelected) 1 else 0)
        parcel.writeString(fileDate)
        parcel.writeString(type)

    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<MediaFile> {
        override fun createFromParcel(parcel: Parcel): MediaFile {
            return MediaFile(parcel)
        }

        override fun newArray(size: Int): Array<MediaFile?> {
            return arrayOfNulls(size)
        }
    }
}
class FolderData() : Parcelable
{
    var folders: MutableList<String> = mutableListOf()
    var imagesByFolder: MutableMap<String, MutableList<MediaFile>> = mutableMapOf()
    var count: Int = 0

    constructor(parcel: Parcel) : this()
    {
        folders = parcel.createStringArrayList() ?: mutableListOf()
        val tempMap = mutableMapOf<String, ArrayList<MediaFile>>()
        parcel.readMap(tempMap, MediaFile::class.java.classLoader)
        imagesByFolder = tempMap.mapValues { it.value.toMutableList() }.toMutableMap()
        count = parcel.readInt()
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeStringList(folders)
        val tempMap = imagesByFolder.mapValues { it.value as ArrayList<MediaFile> }
        parcel.writeMap(tempMap)
        parcel.writeInt(count)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<FolderData> {
        override fun createFromParcel(parcel: Parcel): FolderData {
            return FolderData(parcel)
        }

        override fun newArray(size: Int): Array<FolderData?> {
            return arrayOfNulls(size)
        }
    }

    fun reverse() {
        folders.reverse()
        imagesByFolder = imagesByFolder.mapValues { it.value.asReversed().toMutableList() }.toMutableMap()
    }

    fun getMediaFilesForFolder(folderName: String): List<MediaFile>? {
        return imagesByFolder[folderName]
    }
    fun clearData() {
        folders.clear()
        imagesByFolder.clear()
        count = 0
    }

    fun addData(other: FolderData) {
        // Add folders from the other FolderData object
        folders.addAll(other.folders)

        // Merge imagesByFolder from the other FolderData object
        other.imagesByFolder.forEach { (folder, mediaFiles) ->
            imagesByFolder.merge(folder, mediaFiles) { currentMediaFiles, newMediaFiles ->
                currentMediaFiles.addAll(newMediaFiles)
                currentMediaFiles
            }
        }

        // Update count
        count += other.count
    }
}