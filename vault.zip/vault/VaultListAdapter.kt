package com.applock.lock.apps.fingerprint.password.navigation.vault

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.utils.ALL_FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.AUDIO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VIDEO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.loadAudioThumbnail
import com.bumptech.glide.Glide
import java.util.Locale

class VaultListAdapter(val ctx: Context, var folderData: FolderData, var type: String) :
    RecyclerView.Adapter<VaultListAdapter.ViewHolder>(), Filterable {
    private var TAG = "VaultListAdapter+++++"

    private var filteredData: MutableList<MediaFile> = mutableListOf()
    private var itemClickListener: OnItemClickListener? = null

    interface OnItemClickListener {
        fun onVaultItemClick(
            position: Int,
            folder: String,
            type: String,
            imagesByFolder: MutableMap<String, MutableList<MediaFile>>
        )
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.itemClickListener = listener
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvImageName: TextView = itemView.findViewById(R.id.tvImageName)
        private val ivVaultImage: ImageView = itemView.findViewById(R.id.ivVaultImage)
        private val tvImageTime: TextView = itemView.findViewById(R.id.tvImageTime)

        fun bind(position: Int)
        {

            Log.d(TAG, "------Folder-----"+folderData.folders[position])
            Log.d(TAG, "------Files in Folder-----"+folderData.imagesByFolder[folderData.folders[position]]!!.size.toString())

            tvImageName.text = folderData.folders[position]


            /*val countType = " "+type.replaceFirstChar {  if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
            if(folderData.imagesByFolder[folderData.folders[position]]!!.size>1){
               tvImageTime.text = folderData.imagesByFolder[folderData.folders[position]]!!.size.toString()+countType+"s"

            }else{
               tvImageTime.text = folderData.imagesByFolder[folderData.folders[position]]!!.size.toString()+countType
            }*/

            if (folderData.imagesByFolder.isNotEmpty())
            {
                val filesInFirstFolder = folderData.imagesByFolder[folderData.folders[position]]
                if (!filesInFirstFolder.isNullOrEmpty())
                {


                    val countType = " "+filesInFirstFolder[0].type.replaceFirstChar {  if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
                    if(folderData.imagesByFolder[folderData.folders[position]]!!.size>1){
                        tvImageTime.text = folderData.imagesByFolder[folderData.folders[position]]!!.size.toString()+countType+"s"

                    }else{
                        tvImageTime.text = folderData.imagesByFolder[folderData.folders[position]]!!.size.toString()+countType
                    }

                    if(filesInFirstFolder[0].type=="photo"){Glide.with(ctx).load(filesInFirstFolder[0].filePath).into(ivVaultImage)}
                    if(filesInFirstFolder[0].type=="video"){Glide.with(ctx).load(filesInFirstFolder[0].filePath).into(ivVaultImage)}
                    if(filesInFirstFolder[0].type=="audio"){Glide.with(ctx).load(R.drawable.ic_audio_folder).into(ivVaultImage) }
                    if(filesInFirstFolder[0].type=="file"){Glide.with(ctx).load(R.drawable.ic_file_folder).into(ivVaultImage)}


                   /* if(type== PHOTO_TYPE || type== VIDEO_TYPE|| type==ALL_FILE_TYPE)
                    {
                        Glide.with(ctx).load(filesInFirstFolder[0].filePath).into(ivVaultImage)
                    }
                    else if(type== AUDIO_TYPE)
                    {
                        Glide.with(ctx).load(R.drawable.ic_audio_folder).into(ivVaultImage)
                    }
                    else if(type== FILE_TYPE)
                    {
                        Glide.with(ctx).load(R.drawable.ic_file_folder).into(ivVaultImage)

                    }*/

                }
            }


            // Click listener for the item view
            itemView.setOnClickListener {
                itemClickListener?.onVaultItemClick(position,folderData.folders[position],type,folderData.imagesByFolder)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_vault_data, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(position)
    }

    override fun getItemCount(): Int {
       Log.w(TAG, "getItemCount++++folders+++Size()----: ${folderData.folders.size}")
        Log.w(TAG, "getItemCount++++imagesByFolder+++Count()----: ${folderData.imagesByFolder.size}")
        return folderData.folders.size
    }

 override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults? {
                val charString = constraint.toString().lowercase(Locale.getDefault())
                filteredData = if (charString.isEmpty()) {
                    mutableListOf()
                } else {
                    folderData.imagesByFolder.values.flatten().filter {
                        it.fileName.lowercase(Locale.getDefault()).contains(charString)
                    }.toMutableList()
                }
                val filterResults = FilterResults()
                filterResults.values = filteredData
                return filterResults
                return null
            }

            @Suppress("UNCHECKED_CAST")
            override fun publishResults(
                constraint: CharSequence?,
                results: FilterResults?
            ) {
                filteredData = results?.values as MutableList<MediaFile>? ?: mutableListOf()
                notifyDataSetChanged()
            }
        }
    }

    fun addVaultData(folderData: FolderData, type: String) {
        this.folderData = folderData
        this.type = type
        notifyDataSetChanged()
    }
}
