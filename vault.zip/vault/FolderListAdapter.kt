package com.applock.lock.apps.fingerprint.password.navigation.vault

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.utils.AUDIO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VIDEO_TYPE
import com.bumptech.glide.Glide
import java.util.Locale

class FolderListAdapter(val ctx: Context, var folderData: FolderData,var type: String) :
    RecyclerView.Adapter<FolderListAdapter.ViewHolder>(){

    private var itemClickListener: OnItemClickListener? = null

    interface OnItemClickListener {
        fun onFolderItemClick(position: Int, folder: String)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.itemClickListener = listener
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvAlbumName: TextView = itemView.findViewById(R.id.tvAlbumName)
        private val ivFolderThumb: ImageView = itemView.findViewById(R.id.ivFolderThumb)
        private val tvCount: TextView = itemView.findViewById(R.id.tvCount)

        @SuppressLint("SetTextI18n")
        fun bind(position: Int) {
            tvAlbumName.text = folderData.folders[position]

/*
            val countType = " "+type.replaceFirstChar {  if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
            if(folderData.imagesByFolder[folderData.folders[position]]!!.size>1){
                tvCount.text = folderData.imagesByFolder[folderData.folders[position]]!!.size.toString()+countType+"s"

            }else{
                tvCount.text = folderData.imagesByFolder[folderData.folders[position]]!!.size.toString()+countType
            }*/

            if (folderData.imagesByFolder.isNotEmpty())
            {
                val filesInFirstFolder = folderData.imagesByFolder[folderData.folders[position]]
                if (!filesInFirstFolder.isNullOrEmpty())
                {

                    val countType = " "+filesInFirstFolder[0].type.replaceFirstChar {  if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
                    if(folderData.imagesByFolder[folderData.folders[position]]!!.size>1){
                        tvCount.text = folderData.imagesByFolder[folderData.folders[position]]!!.size.toString()+countType+"s"

                    }else{
                        tvCount.text = folderData.imagesByFolder[folderData.folders[position]]!!.size.toString()+countType
                    }



                    if(filesInFirstFolder[0].type=="photo"){Glide.with(ctx).load(filesInFirstFolder[0].filePath).into(ivFolderThumb)}
                    if(filesInFirstFolder[0].type=="video"){Glide.with(ctx).load(filesInFirstFolder[0].filePath).into(ivFolderThumb)}
                    if(filesInFirstFolder[0].type=="audio"){Glide.with(ctx).load(R.drawable.ic_audio_folder).into(ivFolderThumb)}
                    if(filesInFirstFolder[0].type=="file"){Glide.with(ctx).load(R.drawable.ic_file_folder).into(ivFolderThumb)}


                    /*if(type==PHOTO_TYPE || type == VIDEO_TYPE)
                    {
                    Glide.with(ctx).load(filesInFirstFolder[0].filePath).into(ivFolderThumb)
                    }
                    if(type== AUDIO_TYPE){
                        Glide.with(ctx).load(ctx.resources.getDrawable(R.drawable.ic_audio_folder)).into(ivFolderThumb)
                    }
                    if(type== FILE_TYPE){
                        Glide.with(ctx).load(ctx.resources.getDrawable(R.drawable.ic_file_folder)).into(ivFolderThumb)
                    }*/
                }
            }

            // Click listener for the item view
            itemView.setOnClickListener {
                itemClickListener?.onFolderItemClick(position,folderData.folders[position])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_folder, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(position)
    }

    override fun getItemCount(): Int {
        return folderData.folders.size
    }

}
