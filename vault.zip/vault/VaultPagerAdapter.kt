package com.applock.lock.apps.fingerprint.password.navigation.vault

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.activity.VaultPreviewActivity
import com.applock.lock.apps.fingerprint.password.databinding.VaultItemLayoutBinding
import com.bumptech.glide.Glide

class VaultPagerAdapter(
    val selectedPreviewFilesData: ArrayList<MediaFile>,
   val context: Context
) :
    RecyclerView.Adapter<VaultPagerAdapter.IntroSlideViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IntroSlideViewHolder {
        return IntroSlideViewHolder(
            VaultItemLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun getItemCount(): Int {
        return selectedPreviewFilesData.size
    }

    override fun onBindViewHolder(holder: IntroSlideViewHolder, position: Int) {
        holder.bind(selectedPreviewFilesData[position], position)
    }

    inner class IntroSlideViewHolder(private val binding: VaultItemLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(vaultPagerFile: MediaFile, position: Int) {
            Glide.with(context).load(vaultPagerFile.filePath).into(binding.ivVaultPager)
        }
    }
}
