package com.applock.lock.apps.fingerprint.password.activity

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.gesture.GestureLibraries
import android.gesture.GestureLibrary
import android.gesture.GestureOverlayView
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Base64
import android.view.ContextThemeWrapper
import android.view.SurfaceView
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.core.app.ActivityCompat
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.utils.AppInterface
import com.applock.lock.apps.fingerprint.password.utils.CameraFuncation
import com.applock.lock.apps.fingerprint.password.utils.ConnectionDetector
import com.applock.lock.apps.fingerprint.password.utils.DIGIT_BG
import com.applock.lock.apps.fingerprint.password.utils.ServicePreference
import com.applock.lock.apps.fingerprint.password.utils.THEME_TYPE
import com.applock.lock.apps.fingerprint.password.utils.getBitmap
import com.applock.lock.apps.fingerprint.password.utils.getThemeType
import com.applock.lock.apps.fingerprint.password.utils.hideStatusBarAndNavigationBar
import com.applock.lock.apps.fingerprint.password.view.ForgotPasswordDialog
import com.applock.lock.apps.fingerprint.password.view.SavePatternLockActivty
import java.util.*

class GestureLockActivity : Activity() {
    var mLibrary: GestureLibrary? = null
    var gestures: GestureOverlayView? = null
    var isCorrectPasswordEntered = false
    var rootview: LinearLayout? = null

    //ImageView ivpopup;
    var img_dot: ImageView? = null
    var isInternetPresent = false
    var cd: ConnectionDetector? = null
    var datas: String? = null
    var icon: Drawable? = null
    var packagename: String? = null
    var shakeanimation: Animation? = null
    var passwordTry = 0
    var from_app = false
    var count = 0
    var Onclick = View.OnClickListener { v -> // TODO Auto-generated method stub
        when (v.id) {
            else -> {}
        }
    }
    private var cameraFuncation: CameraFuncation? = null
    private var surfaceView: SurfaceView? = null

    /**
     * our gesture listener
     */
    private val handleGestureListener =
        GestureOverlayView.OnGesturePerformedListener { gestureView, gesture ->
            val predictions = mLibrary!!.recognize(gesture)

            // one prediction needed
            if (predictions.size > 0) {
                val prediction = predictions[0]
                // checking prediction
                if (prediction.score >= 4) {
                    if (from_app) {
                        val i = Intent(this@GestureLockActivity, MainActivity::class.java)
                        startActivityForResult(i, 58)
                    } else {
                        val currentapiVersion = Build.VERSION.SDK_INT
                        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP_MR1) {
                            val servicePreference = ServicePreference(
                                applicationContext
                            )
                            servicePreference.SetLockUnlock(true)
                            setResult(RESULT_OK)
                            finish()
                        } else {
                            SavePreferences("Lock", "True")
                            isCorrectPasswordEntered = true
                            if (currentapiVersion >= Build.VERSION_CODES.LOLLIPOP) {
                                setResult(RESULT_OK)
                                finish()
                            } else {
                                setResult(RESULT_OK)
                                finish()
                            }
                        }
                    }
                } else {
                    img_dot!!.startAnimation(shakeanimation)
                    passwordTry = passwordTry + 1
                    Toast.makeText(applicationContext, "Enter correct password", Toast.LENGTH_SHORT)
                        .show()
                    Handler().postDelayed({ // TODO Auto-generated method stub
                        val permission = Grant_Permission()
                        if (permission) {
                            if (passwordTry >= 1) {
                                passwordTry = 0
                                if (cameraFuncation != null) {
                                    cameraFuncation!!.tackPicture(datas)
                                }
                            }
                        }
                    }, 600)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideStatusBarAndNavigationBar(this)
        setContentView(R.layout.activity_gesturelockactivity)
        try {
            surfaceView = findViewById<View>(R.id.picSurfaceView) as SurfaceView
            cameraFuncation = CameraFuncation(applicationContext, surfaceView!!)
            shakeanimation = AnimationUtils.loadAnimation(this, R.anim.shake)

            //----------------check internet connection-----------------
            cd = ConnectionDetector(this@GestureLockActivity)
            isInternetPresent = cd!!.isConnectingToInternet

            //-----------------------set background image-------------------------------
            val bitmap: Bitmap
            rootview = findViewById<View>(R.id.rootview) as LinearLayout
            if (getThemeType(applicationContext, THEME_TYPE) != packageName) {
                rootview!!.background = getBitmap(
                    applicationContext, DIGIT_BG
                )
                bitmap = (getBitmap(
                    applicationContext,
                    DIGIT_BG
                ) as BitmapDrawable).bitmap
            } else {
                if (getBitmap(applicationContext, DIGIT_BG) == null) {
                    rootview!!.setBackgroundResource(R.drawable.applock_0)
                    bitmap = BitmapFactory.decodeResource(resources, R.drawable.applock_0)
                } else {
                    rootview!!.background = getBitmap(
                        applicationContext, DIGIT_BG
                    )
                    bitmap = (getBitmap(
                        applicationContext,
                        DIGIT_BG
                    ) as BitmapDrawable).bitmap
                }
            }
            val d: Drawable = BitmapDrawable(
                resources, bitmap
            )
            rootview!!.setBackgroundDrawable(d)

            //---------set apps name ,icon and forget password------------------------------
            img_dot = findViewById<View>(R.id.img_dot) as ImageView
            val tvForgotPass = findViewById<TextView>(R.id.tvForgotPass)
            val tvCancel = findViewById<TextView>(R.id.tvCancel)
            tvCancel.setOnClickListener { view: View? -> onBackPressed() }
            tvForgotPass.setOnClickListener { view: View? -> displaysecurityDialogue() }
            val extras = intent.extras
            if (extras != null) {
                datas = extras.getString("Packagename")
                from_app = intent.getBooleanExtra("from_app", false)
            } else {
                datas = packageName
            }
            try {
                icon = packageManager.getApplicationIcon(datas!!)
            } catch (e: PackageManager.NameNotFoundException) {
                e.printStackTrace()
            }
            img_dot!!.setImageDrawable(icon)

            //------------------------------Gesture lock coed--------------------------------------------
            gestures = findViewById<View>(R.id.gestures) as GestureOverlayView
            gestures!!.addOnGesturePerformedListener(handleGestureListener)
            gestures!!.gestureStrokeAngleThreshold = 90.0f
            mLibrary =
                GestureLibraries.fromFile(getExternalFilesDir(null).toString() + "/" + "gesture.txt")
            mLibrary!!.load()
        } catch (e: Exception) {
        }
        val rand = Random()
        val n = rand.nextInt(3)
        if (n == 1) {
            AdLoard()
        }
    }

    override fun onStart() {
        super.onStart()
        // to lock app while minimize and reopen
        // SavePreferences("Lock", "True");
        isCorrectPasswordEntered = false
    }

    override fun onStop() {
        super.onStop()
        if (!isCorrectPasswordEntered) {
            SavePreferences("Lock", "False")
        }
    }

    //------------------------------check phone state permission is grant or not-------------------------------------
    fun Grant_Permission(): Boolean {
        var permission = true
        permission = if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.CAMERA),
                REQUEST_CODE_ASK_PERMISSIONS
            )
            false
        } else {
            true
        }
        return permission
    }

    private fun SavePreferences(key: String, value: String) {
        val sharedPreferences = getSharedPreferences("pref", 0)
        val editor = sharedPreferences.edit()
        editor.putString(key, value)
        editor.commit()
    }

    private fun showFilterPopup(v: View) {
        val wrapper: Context = ContextThemeWrapper(
            applicationContext,
            R.style.YourActionBarWidget
        )
        val popup = PopupMenu(wrapper, v)
        popup.menuInflater.inflate(
            R.menu.menu_popup_pattern,
            popup.menu
        )

        // Setup menu item selection
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_keyword -> {
                    displaysecurityDialogue()
                    true
                }
                else -> false
            }
        }
        // Handle dismissal with: popup.setOnDismissListener(...);
        // Show the menu
        popup.show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            REQUEST_CODE_ASK_PERMISSIONS -> if (grantResults[0] >= 0) {
                //------------------if permission granted on button click then after allow to redirect----
                if (passwordTry >= 1) {
                    passwordTry = 0
                    if (cameraFuncation != null) {
                        cameraFuncation!!.tackPicture(datas)
                    }
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    override fun onBackPressed() {
        count++
        if (count < 2) {
            Toast.makeText(
                this@GestureLockActivity, "Press again to exit!",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val startMain = Intent(Intent.ACTION_MAIN)
            startMain.addCategory(Intent.CATEGORY_HOME)
            startMain.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(startMain)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)
        //Log.d("onactivity result", "true");
        setResult(RESULT_OK)
        finish()
    }

    fun displaysecurityDialogue() {

        ForgotPasswordDialog(this).showDialog(object: AppInterface.OnForgetPasswordDialogListener {
            override fun onForgetPasswordDone() {
                val i = Intent(this@GestureLockActivity, SavePatternLockActivty::class.java)
                startActivityForResult(i, 2)
            }
        })

    }

    fun AdLoard() {
        //loadAds.loadInterstitialAd(this,1);
    }

    companion object {
        private const val REQUEST_CODE_ASK_PERMISSIONS = 135
        fun StringToBitMap(encodedString: String?): Bitmap? {
            return try {
                val encodeByte =
                    Base64.decode(encodedString, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(
                    encodeByte, 0,
                    encodeByte.size
                )
            } catch (e: Exception) {
                e.message
                null
            }
        }
    }
}