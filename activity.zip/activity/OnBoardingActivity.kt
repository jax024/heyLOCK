package com.applock.lock.apps.fingerprint.password.activity

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.Dialog
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

import androidx.viewpager2.widget.ViewPager2
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.databinding.FragmentOnboardingBinding
import com.applock.lock.apps.fingerprint.password.navigation.boarding.OnBoardingAdapter
import com.applock.lock.apps.fingerprint.password.navigation.boarding.OnBoardingSlide
import com.applock.lock.apps.fingerprint.password.utils.PreferenceManager
import com.applock.lock.apps.fingerprint.password.utils.isAllPermissionsGranted
import java.util.Locale
import java.util.SortedMap
import java.util.TreeMap

class OnBoardingActivity : AppCompatActivity() {
    private val TAG = "OnBoardingActivity+++++++"
    var binding: FragmentOnboardingBinding? = null

    private val introslideradapter by lazy {
        OnBoardingAdapter(
            listOf(
                OnBoardingSlide(
                    "Protect your privacy",
                    "To protect your application from being\n" +
                            "accessed by others.",
                    R.drawable.img_onboarding1
                ),
                OnBoardingSlide(
                    "Save in the super secure cloud",
                    "Powerful photo, folder, Video or\n" +
                            "folder lock.",
                    R.drawable.img_onboarding2
                ),
                OnBoardingSlide(
                    "Private Browser",
                    "Browse incognito without leaving\n" +
                            "any traces.",
                    R.drawable.img_onboarding3
                )
            )
        )
    }

    @SuppressLint("SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = FragmentOnboardingBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        Init()
    }

    private fun Init() {

        navigateToBordingScreen()
    }

    private fun navigateToLockScreen() {

        startActivity(Intent(this@OnBoardingActivity, FirstActivity::class.java))
        finish()

    }

    private fun navigateToBordingScreen() {

        if (!PreferenceManager.getInstance(this@OnBoardingActivity).isOnBordingShow()) {
            moveToNextScreen()
        }else{
            binding?.vpOnbordingPager?.adapter = introslideradapter
            binding?.inOnbordingIndicator?.setViewPager(binding?.vpOnbordingPager)

            binding?.vpOnbordingPager?.registerOnPageChangeCallback(object :
                ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    super.onPageSelected(position)

                    if (position == introslideradapter.itemCount - 1) {
                        binding?.btnOnbordingNext?.text = "Get Started"
                        binding?.btnOnbordingNext?.setOnClickListener {
                            moveToNextScreen()
                        }
                    } else {
                        binding?.btnOnbordingNext?.text = "Next"
                        binding?.btnOnbordingNext?.setOnClickListener {
                            binding?.vpOnbordingPager?.currentItem?.let {
                                binding?.vpOnbordingPager?.setCurrentItem(it + 1, false)
                            }
                        }
                    }
                }
            })
        }

    }


    private fun moveToNextScreen()
    {
        PreferenceManager.getInstance(this@OnBoardingActivity).setOnBordingShow(false)
        if (!isAllPermissionsGranted(this@OnBoardingActivity))
        {
            Log.d("navigateToPermissionScreen+++", "--------navigateToPermissionScreen")
            navigateToPermissionScreen()
        } else {
            navigateToLockScreen()
        }
    }

    private fun navigateToPermissionScreen() {
        openOradoPermissionScreen()
    }


    private fun openOradoPermissionScreen() {
        if ("xiaomi" == Build.MANUFACTURER.lowercase() && !PreferenceManager.getInstance(
                this@OnBoardingActivity
            ).isAutoStartDialogShow()
        ) {
            val iAutoStartManagementIntent = Intent()
            iAutoStartManagementIntent.component = ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
            )
            startActivity(iAutoStartManagementIntent)
            PreferenceManager.getInstance(this@OnBoardingActivity).setAutoStartDialogShow(true)
        } else {
            val imm =
                getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            if (imm.isAcceptingText) {
                val view1: View = currentFocus!!
                if (view1 != null) {
                    val manager =
                        getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    manager.hideSoftInputFromWindow(view1.windowToken, 0)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val model = Build.MANUFACTURER + " " + Build.MODEL
                val lg = "LG"
                val nexus = "Nexus"
                val Sony = "Sony"
                if (model.lowercase(Locale.getDefault())
                        .contains(lg.lowercase(Locale.getDefault()))
                ) {
                    if (model.lowercase(Locale.getDefault())
                            .contains(nexus.lowercase(Locale.getDefault()))
                    ) {
                        if (needPermissionForBlocking(this@OnBoardingActivity)
                        ) {
                            Log.d(
                                "needPermissionForBlocking+++",
                                "--------navigateToPermissionScreen"
                            )
                            navigateToAppPermissionScreen()

                        } else {
                            if (printForegroundTask() != null) {
                                navigateToAppPermissionScreen()

                            } else {
                                displayDialogue()
                            }
                        }
                    } else {
                        navigateToAppPermissionScreen()
                    }
                } else {
                    if (needPermissionForBlocking(
                            this@OnBoardingActivity
                        )
                    ) {
                        navigateToAppPermissionScreen()

                    } else {
                        if (printForegroundTask() != null) {
                            navigateToAppPermissionScreen()
                        } else {
                            displayDialogue()
                        }
                    }
                }
            } else {
                navigateToAppPermissionScreen()
            }
        }
    }

    private fun navigateToAppPermissionScreen() {
        startActivity(Intent(this@OnBoardingActivity, AppPermissionActivity::class.java))
        finish()
    }

    private fun printForegroundTask(): String? {
        var currentApp: String? = null
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val usm =
                getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val time = System.currentTimeMillis()
            val appList =
                usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, time - 1000 * 1000, time)
            if (appList != null && appList.size > 0) {
                val mySortedMap: SortedMap<Long, UsageStats> = TreeMap()
                for (usageStats in appList) {
                    mySortedMap[usageStats.lastTimeUsed] = usageStats
                }
                if (mySortedMap != null && !mySortedMap.isEmpty()) {
                    currentApp = mySortedMap[mySortedMap.lastKey()]!!.packageName
                }
            }
        } else {
            currentApp = am.getRunningTasks(1)[0].topActivity!!.packageName
        }
        return currentApp
    }

    private fun needPermissionForBlocking(context: Context): Boolean {
        val appOps =
            context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            "android:get_usage_stats",
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }


    private fun displayDialogue() {
        val dialog = Dialog(this@OnBoardingActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.lout_permission)
        dialog.setCancelable(true)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setGravity(Gravity.BOTTOM)
        val tvCancel = dialog.findViewById<TextView>(R.id.tvcancel)
        val ivTurnOn = dialog.findViewById<TextView>(R.id.tvTurnOn)
        ivTurnOn.setOnClickListener {
            if (printForegroundTask() == null) {
                hasPermissionToUsageAccess()
            }
            dialog.dismiss()
        }
        tvCancel.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }


    private fun hasPermissionToUsageAccess(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true
        }
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            packageName
        )
        if (mode == AppOpsManager.MODE_ALLOWED) {
            return true
        }
        appOps.startWatchingMode(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            packageName,
            object : AppOpsManager.OnOpChangedListener {
                override fun onOpChanged(op: String, packageName: String) {
                    val mode = appOps.checkOpNoThrow(
                        AppOpsManager.OPSTR_GET_USAGE_STATS,
                        Process.myUid(), packageName
                    )
                    if (mode != AppOpsManager.MODE_ALLOWED) {
                        return
                    }
                    appOps.stopWatchingMode(this)
                    if ("xiaomi" == Build.MANUFACTURER.lowercase()) {
                        return
                    }
                    val iAppPermissionIntent = Intent(this@OnBoardingActivity, AppPermissionActivity::class.java)
                    iAppPermissionIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    setResult(Activity.RESULT_OK)
                    startActivity(iAppPermissionIntent)
                    finish()
                }
            })
        requestAccessPermission()
        return false
    }

    private fun requestAccessPermission() {
        try {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            startActivity(intent)
            Handler(Looper.myLooper()!!).postDelayed({
                val iSettingPermissionIntent = Intent(this@OnBoardingActivity, SettingPermissionActivity::class.java)
                iSettingPermissionIntent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                startActivity(iSettingPermissionIntent)
            }, 1200)
        } catch (e: Exception) {
            Log.d("+++++", e.message.toString())
        }
    }


    companion object

}