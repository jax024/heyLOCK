package com.applock.lock.apps.fingerprint.password.activity

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.databinding.ActivityFolderListBinding
import com.applock.lock.apps.fingerprint.password.navigation.vault.FolderData
import com.applock.lock.apps.fingerprint.password.navigation.vault.FolderListAdapter
import com.applock.lock.apps.fingerprint.password.navigation.vault.MediaFile
import com.applock.lock.apps.fingerprint.password.navigation.vault.VaultFragment
import com.applock.lock.apps.fingerprint.password.utils.AUDIO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.INTENT_SELECTED_IMAGES
import com.applock.lock.apps.fingerprint.password.utils.IS_FROM_VAULT
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.TITLE_AUDIOS
import com.applock.lock.apps.fingerprint.password.utils.TITLE_FILES
import com.applock.lock.apps.fingerprint.password.utils.TITLE_PHOTOS
import com.applock.lock.apps.fingerprint.password.utils.TITLE_VIDEOS
import com.applock.lock.apps.fingerprint.password.utils.TYPE
import com.applock.lock.apps.fingerprint.password.utils.VAULT_ALL_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VAULT_AUDIO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VAULT_FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VAULT_PHOTO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VAULT_VIDEO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VIDEO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.gone
import com.applock.lock.apps.fingerprint.password.utils.visible
import java.io.File
import java.util.regex.Matcher
import java.util.regex.Pattern

data class ResourceData(
    val titleResId: String,
    val noFolderDataResId: Int,
    val drawableResId: Int,
    val folderData: FolderData
)
class FolderListActivity : AppCompatActivity(), FolderListAdapter.OnItemClickListener {

    private lateinit var binding: ActivityFolderListBinding
    private val TAG = "FolderListActivity++++++"
    var adapter: FolderListAdapter? = null
    var type = PHOTO_TYPE
    var isFromVault = false

    lateinit var receivedFolderData: FolderData

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFolderListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        getIntentData(intent)
        clickListeners()
    }
    private fun clickListeners() {
        binding.ivBack.setOnClickListener { onBackPressed() }

        binding.flAddPhoto.setOnClickListener {
            binding.flAddPhoto.gone()

            val resourceData = when (type) {
                VAULT_PHOTO_TYPE -> ResourceData(TITLE_PHOTOS, R.string.no_photo_in_data, R.drawable.no_photo, VaultFragment.imageFolderData)
                VAULT_VIDEO_TYPE -> ResourceData(TITLE_VIDEOS, R.string.no_video_in_data, R.drawable.no_video, VaultFragment.videoFolderData)
                VAULT_AUDIO_TYPE -> ResourceData(TITLE_AUDIOS, R.string.no_audio_in_data, R.drawable.ic_audio_folder, VaultFragment.audioFolderData)
                VAULT_FILE_TYPE -> ResourceData(TITLE_FILES, R.string.no_file_in_data, R.drawable.ic_file_folder, VaultFragment.documentFolderData)
                VAULT_ALL_TYPE -> ResourceData(TITLE_FILES, R.string.no_file_in_data, R.drawable.ic_file_folder, VaultFragment.allFolderData)
                else -> ResourceData(TITLE_FILES, R.string.no_file_in_data, R.drawable.ic_file_folder,  VaultFragment.allFolderData) // Default values
            }

            binding.tvTitle.text = resourceData.titleResId
            binding.tvNoFolderData.text = getString(resourceData.noFolderDataResId)
            receivedFolderData = resourceData.folderData

            val drawable = ContextCompat.getDrawable(this@FolderListActivity, resourceData.drawableResId)
            binding.ivNoFolderData.setImageDrawable(drawable)

            setRecyclerViewData()
        }
    }


    private fun getIntentData(intent: Intent?) {
        type = intent?.getStringExtra(TYPE).toString()
        isFromVault = intent?.getBooleanExtra(IS_FROM_VAULT, false) ?: false

        setupUIComponents()
        setRecyclerViewData()
    }

    private fun setupUIComponents() {
        val (titleResId, noFolderDataResId, drawableResId, folderData,addFile) = getDrawableResourceData(type)

        binding.tvTitle.text =titleResId
        binding.tvNoFolderData.text = getString(noFolderDataResId)
        binding.btnAddPhoto.text = getString(addFile)
        receivedFolderData = folderData

        val drawable = ContextCompat.getDrawable(this@FolderListActivity, drawableResId)
        binding.ivNoFolderData.setImageDrawable(drawable)

        binding.flAddPhoto.visibility = if (isFromVault) View.VISIBLE else View.GONE
    }

    private fun getDrawableResourceData(type: String?): VaultQuad<String, Int, Int, FolderData,Int> {
        return when (type)
        {

            PHOTO_TYPE -> VaultQuad(TITLE_PHOTOS, R.string.no_photo_in_data, R.drawable.no_photo, VaultFragment.imageFolderData,R.string.lbl_add_photo)
            VIDEO_TYPE -> VaultQuad(TITLE_VIDEOS, R.string.no_video_in_data, R.drawable.no_video, VaultFragment.videoFolderData,R.string.lbl_add_video)
            AUDIO_TYPE -> VaultQuad(TITLE_AUDIOS, R.string.no_audio_in_data, R.drawable.ic_audio_folder, VaultFragment.audioFolderData,R.string.lbl_add_audio)
            FILE_TYPE -> VaultQuad(TITLE_FILES, R.string.no_file_in_data, R.drawable.ic_file_folder, VaultFragment.documentFolderData,R.string.lbl_add_file)

            VAULT_PHOTO_TYPE -> VaultQuad(TITLE_FILES, R.string.msg_no_photo_in_vau, R.drawable.no_photo, VaultFragment.cHideImageFolderData,R.string.lbl_add_photo)
            VAULT_VIDEO_TYPE -> VaultQuad(TITLE_FILES, R.string.msg_no_video_in_vau, R.drawable.no_video, VaultFragment.cHideVideoFolderData,R.string.lbl_add_video)
            VAULT_AUDIO_TYPE -> VaultQuad(TITLE_FILES, R.string.msg_no_audio_in_vau, R.drawable.ic_audio_folder, VaultFragment.cHideAudioFolderData,R.string.lbl_add_audio)
            VAULT_FILE_TYPE, VAULT_ALL_TYPE ->
                {
                val titleResId = TITLE_FILES
                val noFolderDataResId = R.string.msg_no_file_in_vau
                val drawableResId = R.drawable.ic_file_folder
               // val folderData = if (type == VAULT_FILE_TYPE) VaultFragment.cHideFileFolderData else VaultFragment.cHideAllFolderData
                val folderData = VaultFragment.cHideFileFolderData
                VaultQuad(titleResId, noFolderDataResId, drawableResId, folderData,R.string.lbl_add_file)
            }
            else -> VaultQuad(TITLE_FILES, R.string.no_file_in_data, R.drawable.ic_file_folder, VaultFragment.cHideImageFolderData,R.string.lbl_add_file) // Default values
        }
    }

    data class VaultQuad<A, B, C, D, E>(val title: A, val noDataMsg: B, val noDataImage: C, val folderData: D, val addData: E)


    private fun setRecyclerViewData() {
        if (receivedFolderData.imagesByFolder.isEmpty()) {
            Log.d(TAG, "$type -- receivedFolderData is empty")
            binding.rlNoFolderDataView.visible()
            binding.rvFolderList.gone()
            return
        }

        setFolderListRecyclerView(receivedFolderData)
        binding.rlNoFolderDataView.gone()
        binding.rvFolderList.visible()
    }


    private fun setFolderListRecyclerView(receivedData: FolderData) {
        adapter = FolderListAdapter(this@FolderListActivity, receivedData, type)
        binding.rvFolderList.adapter = adapter
        adapter!!.setOnItemClickListener(this)
    }

    override fun onFolderItemClick(position: Int, foldername: String) {
        if (receivedFolderData.imagesByFolder.containsKey(foldername)) {
             selectedImages = receivedFolderData.imagesByFolder[foldername]
            if (!selectedImages.isNullOrEmpty()) {
                val intent = Intent(this, FileListActivity::class.java)
                intent.putExtra(TYPE, type)
                intent.putExtra(IS_FROM_VAULT, false)
                startActivity(intent)
                finish()
            } else {
                // Handle case when selectedImages is empty
            }
        } else {
            // Handle case when foldername is not found
        }
    }


    companion object {
        var selectedImages: MutableList<MediaFile>? = mutableListOf()

    }

}