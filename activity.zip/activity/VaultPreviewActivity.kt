package com.applock.lock.apps.fingerprint.password.activity

import android.R.attr
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.viewpager2.widget.ViewPager2
import com.applock.lock.apps.fingerprint.password.databinding.ActivityVaultPreviewBinding
import com.applock.lock.apps.fingerprint.password.navigation.vault.FileListAdapter
import com.applock.lock.apps.fingerprint.password.navigation.vault.MediaFile
import com.applock.lock.apps.fingerprint.password.navigation.vault.VaultPagerAdapter
import com.applock.lock.apps.fingerprint.password.utils.IS_FROM_VAULT
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.TYPE
import com.applock.lock.apps.fingerprint.password.utils.gone
import com.applock.lock.apps.fingerprint.password.utils.visible
import com.applock.lock.apps.fingerprint.password.view.MediaDB
import java.io.File
import java.io.IOException
import java.security.AccessController.getContext


class VaultPreviewActivity : AppCompatActivity() {
    private val TAG = "VaultPreviewActivity++++++"

    private lateinit var binding: ActivityVaultPreviewBinding
    private lateinit var pagerAdapter: VaultPagerAdapter
    var adapter: FileListAdapter? = null

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVaultPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        getIntentData(intent)
        clickListners()
    }

    private fun clickListners() {
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
        binding.llUnlockView.setOnClickListener {
            if (receivedFilesData[binding.vpPreviewList.currentItem].type == "photo") {
                unLockPhotoVaultFile(receivedFilesData[binding.vpPreviewList.currentItem])
            }
           else if (receivedFilesData[binding.vpPreviewList.currentItem].type == "video") {
                unLockVideoVaultFile(receivedFilesData[binding.vpPreviewList.currentItem])
            }
          else  if (receivedFilesData[binding.vpPreviewList.currentItem].type == "audio") {
                unLockAudioVaultFile(receivedFilesData[binding.vpPreviewList.currentItem])
            }
            else{if (receivedFilesData[binding.vpPreviewList.currentItem].type == "file") {
                unLockFileVaultFile(receivedFilesData[binding.vpPreviewList.currentItem])
            }}

        }
        binding.llShareView.setOnClickListener {
            shareSelectedVaultFile(receivedFilesData[binding.vpPreviewList.currentItem])
        }
        binding.llDeleteView.setOnClickListener {
            deleteSelectedVaultFile(receivedFilesData[binding.vpPreviewList.currentItem])
        }

/*        binding.llMoveVault.setOnClickListener {
            moveSelectedVaultFile(receivedFilesData[binding.vpPreviewList.currentItem])

        }
        binding.llRotateVault.setOnClickListener {
            rotateSelectedVaultFile(receivedFilesData[binding.vpPreviewList.currentItem])

        }*/

    }

    private fun unLockPhotoVaultFile(mediaFile: MediaFile) {


        val db1 = MediaDB(this@VaultPreviewActivity)
        db1.open()
        Log.d(TAG, "LOCK_IMAGE----db1.getAllImages()-------->" + db1.getAllImages())


        val db = MediaDB(this@VaultPreviewActivity)
        db.open()
        val originalPath = db.originalPath(mediaFile.fileName)

        if (originalPath.isNotEmpty()) {


            Log.d(TAG, "LOCK_IMAGE----OriginalFolderPath:-------->" + originalPath)
            Log.d(
                TAG,
                "LOCK_IMAGE----OriginalFolderPath:-------->" + originalPath.substringBeforeLast("/")
            )
            Log.d(TAG, "LOCK_IMAGE-----UmLockFilename----${mediaFile.fileName}")


            val fileinDirectory = File(mediaFile.filePath)

            val LockPhotoVault = originalPath.substringBeforeLast("/") + "/"
            Log.d(TAG, "LOCK_IMAGE----_DIRECTORY_PATH: $LockPhotoVault")

            if (!File(LockPhotoVault).exists()) {
                File(LockPhotoVault).mkdirs()
            }

            Log.d(
                TAG,
                "LOCK_IMAGE----File(PHOTO_DIRECTORY_PATH).mkdirs(): ${File(LockPhotoVault).exists()}"
            )


            var newfilee = File(LockPhotoVault + "/" + mediaFile.fileName)

            Log.d(TAG, "UNLOCK_IMAGE----new path---${newfilee.path}")

            val isRenamedImage = fileinDirectory.renameTo(newfilee)

            Log.d(TAG, "UNLOCK_IMAGE-----isRenamedImage--?----${isRenamedImage}")

            if (fileinDirectory.exists()) {
                Log.e(TAG, "Fail to UnLock ImageFile------->$fileinDirectory")
            } else {
                Log.d(TAG, "Unlock ImageFile at index------>$fileinDirectory")
                val dbDelete = MediaDB(this@VaultPreviewActivity)
                dbDelete.open()
                dbDelete.deletePath(mediaFile.fileName)

                // Scan the storage
                MediaScannerConnection.scanFile(
                    this@VaultPreviewActivity,
                    arrayOf<String>(Environment.getExternalStorageDirectory().absolutePath),
                    null
                ) { _: String?, _: Uri? -> }

                if (receivedFilesData.size > 0) {
                    receivedFilesData.removeAt(binding.vpPreviewList.currentItem)
                    if (receivedFilesData.size == 0) {
                        onBackPressed()
                    } else {
                        setVaultPreviewPager()
                    }
                }

            }
        } else {
            Toast.makeText(
                applicationContext,
                "Fail to UnLock now!",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun unLockVideoVaultFile(mediaFile: MediaFile) {

        val db1 = MediaDB(this@VaultPreviewActivity)
        db1.open()
        Log.d(TAG, "LOCK_VIDEO----db1.getAllVideos()-------->" + db1.getAllVideos())

        val db = MediaDB(this@VaultPreviewActivity)
        db.open()
        val originalPath = db.originalPathVideo(mediaFile.fileName)

        if (originalPath.isNotEmpty()) {

            Log.d(TAG, "LOCK_VIDEO----OriginalFolderPath:-------->" + originalPath)
            Log.d(
                TAG,
                "LOCK_VIDEO----OriginalFolderPath:-------->" + originalPath.substringBeforeLast("/")
            )
            Log.d(TAG, "LOCK_VIDEO-----UmLockFilename----${mediaFile.fileName}")

            val fileinDirectory = File(mediaFile.filePath)

            val LockVideoVault = originalPath.substringBeforeLast("/") + "/"
            Log.d(TAG, "LOCK_VIDEO----_DIRECTORY_PATH: $LockVideoVault")

            if (!File(LockVideoVault).exists()) {
                File(LockVideoVault).mkdirs()
            }

            Log.d(
                TAG,
                "LOCK_VIDEO----File(PHOTO_DIRECTORY_PATH).mkdirs(): ${File(LockVideoVault).exists()}"
            )


            var newfilee = File(LockVideoVault + "/" + mediaFile.fileName)

            Log.d(TAG, "UNLOCK_VIDEO----new path---${newfilee.path}")

            val isRenamedImage = fileinDirectory.renameTo(newfilee)

            Log.d(TAG, "UNLOCK_VIDEO-----isRenamedImage--?----${isRenamedImage}")

            if (fileinDirectory.exists()) {
                Log.e(TAG, "Fail to UnLock VideoFile------->$fileinDirectory")
            } else {
                Log.d(TAG, "Unlock VideoFile at index------>$fileinDirectory")
                val dbDelete = MediaDB(this@VaultPreviewActivity)
                dbDelete.open()
                dbDelete.deletePathVideo(mediaFile.fileName)

                // Scan the storage
                MediaScannerConnection.scanFile(
                    this@VaultPreviewActivity,
                    arrayOf<String>(Environment.getExternalStorageDirectory().absolutePath),
                    null
                ) { _: String?, _: Uri? -> }

                if (receivedFilesData.size > 0) {
                    receivedFilesData.removeAt(binding.vpPreviewList.currentItem)
                    if (receivedFilesData.size == 0) {
                       onBackPressed()
                    } else {
                        setVaultPreviewPager()
                    }
                }

            }
        } else {
            Toast.makeText(
                applicationContext,
                "Fail to UnLock now!",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun unLockAudioVaultFile(mediaFile: MediaFile) {

        val db1 = MediaDB(this@VaultPreviewActivity)
        db1.open()
        Log.d(TAG, "LOCK_Audio----db1.getAllAudios()-------->" + db1.getAllAudios())


        val db = MediaDB(this@VaultPreviewActivity)
        db.open()
        val originalPath = db.originalPathAudio(mediaFile.fileName)

        if (originalPath.isNotEmpty()) {


            Log.d(TAG, "LOCK_Audio----OriginalFolderPath:-------->" + originalPath)
            Log.d(
                TAG,
                "LOCK_Audio----OriginalFolderPath:-------->" + originalPath.substringBeforeLast("/")
            )
            Log.d(TAG, "LOCK_Audio-----UmLockFilename----${mediaFile.fileName}")


            val fileinDirectory = File(mediaFile.filePath)

            val LockAudioVault = originalPath.substringBeforeLast("/") + "/"
            Log.d(TAG, "LOCK_Audio----_DIRECTORY_PATH: $LockAudioVault")

            if (!File(LockAudioVault).exists()) {
                File(LockAudioVault).mkdirs()
            }

            Log.d(
                TAG,
                "LOCK_Audio----File(PHOTO_DIRECTORY_PATH).mkdirs(): ${File(LockAudioVault).exists()}"
            )


            var newfilee = File(LockAudioVault + "/" + mediaFile.fileName)

            Log.d(TAG, "LOCK_Audio----new path---${newfilee.path}")

            val isRenamedImage = fileinDirectory.renameTo(newfilee)

            Log.d(TAG, "LOCK_Audio-----isRenamedImage--?----${isRenamedImage}")

            if (fileinDirectory.exists()) {
                Log.e(TAG, "Fail to UnLock ImageFile------->$fileinDirectory")
            } else {
                Log.d(TAG, "Unlock AudioFile at index------>$fileinDirectory")
                val dbDelete = MediaDB(this@VaultPreviewActivity)
                dbDelete.open()
                dbDelete.deletePathAudio(mediaFile.fileName)

                // Scan the storage
                MediaScannerConnection.scanFile(
                    this@VaultPreviewActivity,
                    arrayOf<String>(Environment.getExternalStorageDirectory().absolutePath),
                    null
                ) { _: String?, _: Uri? -> }

                if (receivedFilesData.size > 0) {
                    receivedFilesData.removeAt(binding.vpPreviewList.currentItem)
                    if (receivedFilesData.size == 0) {
                        onBackPressed()
                    } else {
                        setVaultPreviewPager()
                    }
                }

            }
        } else {
            Toast.makeText(
                applicationContext,
                "Fail to UnLock now!",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun unLockFileVaultFile(mediaFile: MediaFile) {


        val db1 = MediaDB(this@VaultPreviewActivity)
        db1.open()
        Log.d(TAG, "LOCK_FILE----db1.getAllImages()-------->" + db1.getAllImages())


        val db = MediaDB(this@VaultPreviewActivity)
        db.open()
        val originalPath = db.originalPathFile(mediaFile.fileName)

        if (originalPath.isNotEmpty()) {


            Log.d(TAG, "LOCK_FILE----OriginalFolderPath:-------->" + originalPath)
            Log.d(
                TAG,
                "LOCK_FILE----OriginalFolderPath:-------->" + originalPath.substringBeforeLast("/")
            )
            Log.d(TAG, "LOCK_FILE-----UnLockFilename----${mediaFile.fileName}")


            val fileinDirectory = File(mediaFile.filePath)

            val FileVaultFile = originalPath.substringBeforeLast("/") + "/"
            Log.d(TAG, "LOCK_FILE----_DIRECTORY_PATH: $FileVaultFile")

            if (!File(FileVaultFile).exists()) {
                File(FileVaultFile).mkdirs()
            }

            Log.d(
                TAG,
                "LOCK_FILE----File(FILE_DIRECTORY_PATH).mkdirs(): ${File(FileVaultFile).exists()}"
            )


            var newfilee = File(FileVaultFile + "/" + mediaFile.fileName)

            Log.d(TAG, "LOCK_FILE----new path---${newfilee.path}")

            val isRenamedImage = fileinDirectory.renameTo(newfilee)

            Log.d(TAG, "LOCK_FILE-----isRenamedImage--?----${isRenamedImage}")

            if (fileinDirectory.exists()) {
                Log.e(TAG, "Fail to UnLock File------->$fileinDirectory")
            } else {
                Log.d(TAG, "Unlock File at index------>$fileinDirectory")
                val dbDelete = MediaDB(this@VaultPreviewActivity)
                dbDelete.open()
                dbDelete.deletePathFile(mediaFile.fileName)

                // Scan the storage
                MediaScannerConnection.scanFile(
                    this@VaultPreviewActivity,
                    arrayOf<String>(Environment.getExternalStorageDirectory().absolutePath),
                    null
                ) { _: String?, _: Uri? -> }

                if (receivedFilesData.size > 0) {
                    receivedFilesData.removeAt(binding.vpPreviewList.currentItem)
                    if (receivedFilesData.size == 0) {
                        onBackPressed()
                    } else {
                        setVaultPreviewPager()
                    }
                }

            }
        } else {
            Toast.makeText(
                applicationContext,
                "Fail to UnLock now!",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun shareSelectedVaultFile(mediaFile: MediaFile) {
        try {
                val intent = Intent()
                intent.setAction(Intent.ACTION_SEND)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    val contentUri = FileProvider.getUriForFile(
                      this@VaultPreviewActivity,
                        getApplicationContext().getPackageName() + ".provider",
                        File(mediaFile.filePath.toString())
                    )
                    intent.setDataAndType(contentUri, "*/*")
                } else {
                    intent.setDataAndType(Uri.fromFile(File(mediaFile.filePath.toString())), "*/*")
                }
                startActivity(Intent.createChooser(intent, "Share File"))



        } catch (e: IOException) {
            e.printStackTrace()
        }

    }

    private fun deleteSelectedVaultFile(mediaFile: MediaFile) {
        val dbDelete = MediaDB(this@VaultPreviewActivity)
        dbDelete.open()
        dbDelete.deletePathFile(mediaFile.fileName)

        // Scan the storage
        MediaScannerConnection.scanFile(
            this@VaultPreviewActivity,
            arrayOf<String>(Environment.getExternalStorageDirectory().absolutePath),
            null
        ) { _: String?, _: Uri? -> }

        if (receivedFilesData.size > 0) {
            receivedFilesData.removeAt(binding.vpPreviewList.currentItem)
            if (receivedFilesData.size == 0) {
                onBackPressed()
            } else {
                setVaultPreviewPager()
            }
        }
    }

    private fun moveSelectedVaultFile(mediaFile: MediaFile) {}
    private fun rotateSelectedVaultFile(mediaFile: MediaFile) {}


    private fun getIntentData(intent: Intent?) {
        isFromVault = intent?.getBooleanExtra(IS_FROM_VAULT, false)!!
        type = intent.getStringExtra(TYPE)!!

        receivedFilesData = FileListActivity.selectedItemsList
        binding.tvCount.text = "1/" + receivedFilesData.count().toString()
        setVaultPreviewPager()

/*        if (receivedFilesData[0].type == "photo") {
            binding.llRotateVault.visible()
        }
        if (receivedFilesData[0].type == "video") {
            binding.llRotateVault.gone()
        }
        if (receivedFilesData[0].type == "audio") {
            binding.llRotateVault.gone()

        }
        if (receivedFilesData[0].type == "file") {
            binding.llRotateVault.gone()
        }*/
    }

    private fun setVaultPreviewPager() {
        pagerAdapter = VaultPagerAdapter(receivedFilesData, this@VaultPreviewActivity)
        binding.vpPreviewList.adapter = pagerAdapter

        binding.vpPreviewList.registerOnPageChangeCallback(object :
            ViewPager2.OnPageChangeCallback() {
            @SuppressLint("SetTextI18n")
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)

                val currentCount = position + 1
                Log.d(
                    TAG,
                    "CurrentPage------->${currentCount}" +
                            "CurrentPositionInList----${position}" +
                            "FILE_Type----${receivedFilesData[position].type}" +
                            "FILE_Name----${receivedFilesData[position].fileName}" +
                            "FILE_Path----${receivedFilesData[position].filePath}" +
                            "FILE_Folder----${receivedFilesData[position].folderName}"
                )

                binding.tvCount.text = "$currentCount/" + receivedFilesData.size.toString()
                binding.tvTitle.text = receivedFilesData[position].fileName

/*

                if (receivedFilesData[position].type == "photo") {
                    binding.llRotateVault.visible()
                }
                if (receivedFilesData[position].type == "video") {
                    binding.llRotateVault.gone()

                }
                if (receivedFilesData[position].type == "audio") {
                    binding.llRotateVault.gone()

                }
                if (receivedFilesData[position].type == "file") {
                    binding.llRotateVault.gone()
                }
*/

            }
        })

        binding.vpPreviewList.setPageTransformer(DepthPageTransformer())

    }

    @RequiresApi(21)
    class DepthPageTransformer : ViewPager2.PageTransformer {

        override fun transformPage(view: View, position: Float) {
            view.apply {
                val pageWidth = width
                when {
                    position < -1 -> { // [-Infinity,-1)
                        // This page is way off-screen to the left.
                        alpha = 0f
                    }

                    position <= 0 -> { // [-1,0]
                        // Use the default slide transition when moving to the left page.
                        alpha = 1f
                        translationX = 0f
                        translationZ = 0f
                        scaleX = 1f
                        scaleY = 1f
                    }

                    position <= 1 -> { // (0,1]
                        // Fade the page out.
                        alpha = 1 - position

                        // Counteract the default slide transition.
                        translationX = pageWidth * -position
                        // Move it behind the left page.
                        translationZ = -1f

                        // Scale the page down (between MIN_SCALE and 1).
                        val scaleFactor = (MIN_SCALE + (1 - MIN_SCALE) * (1 - Math.abs(position)))
                        scaleX = scaleFactor
                        scaleY = scaleFactor
                    }

                    else -> { // (1,+Infinity]
                        // This page is way off-screen to the right.
                        alpha = 0f
                    }
                }
            }
        }
    }


    companion object {

        var count = 0
        var type = PHOTO_TYPE
        var isFromVault = false
        private lateinit var receivedFilesData: ArrayList<MediaFile>
        private const val MIN_SCALE = 0.75f

    }


}