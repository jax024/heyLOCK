package com.applock.lock.apps.fingerprint.password.activity

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.applock.lock.apps.fingerprint.password.R

class SettingPermissionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings_permission)
        findViewById<View>(R.id.iv_right).setOnClickListener { finish() }
        findViewById<View>(R.id.llAllowed).setOnClickListener { finish() }
        findViewById<View>(R.id.lout_top).setOnClickListener { finish() }
    }

}
