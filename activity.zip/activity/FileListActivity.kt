package com.applock.lock.apps.fingerprint.password.activity

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.applock.lock.apps.fingerprint.password.databinding.ActivityFileListBinding
import com.applock.lock.apps.fingerprint.password.navigation.lock.VideoPreviewActivity
import com.applock.lock.apps.fingerprint.password.navigation.vault.FileListAdapter
import com.applock.lock.apps.fingerprint.password.navigation.vault.MediaFile
import com.applock.lock.apps.fingerprint.password.navigation.vault.VaultFragment
import com.applock.lock.apps.fingerprint.password.utils.AUDIO_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.AUDIO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.FILE_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.INTENT_HIDETYPE
import com.applock.lock.apps.fingerprint.password.utils.IS_FROM_VAULT
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.REQUEST_HIDE_AUDIOS
import com.applock.lock.apps.fingerprint.password.utils.REQUEST_HIDE_FILES
import com.applock.lock.apps.fingerprint.password.utils.REQUEST_HIDE_PHOTOS
import com.applock.lock.apps.fingerprint.password.utils.REQUEST_HIDE_VIDEOS
import com.applock.lock.apps.fingerprint.password.utils.TYPE
import com.applock.lock.apps.fingerprint.password.utils.VIDEO_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.VIDEO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.gone
import com.applock.lock.apps.fingerprint.password.utils.putAudioHideUri
import com.applock.lock.apps.fingerprint.password.utils.putFileHideUri
import com.applock.lock.apps.fingerprint.password.utils.putImageHideUri
import com.applock.lock.apps.fingerprint.password.utils.putVideoHideUri
import com.applock.lock.apps.fingerprint.password.utils.visible
import com.applock.lock.apps.fingerprint.password.view.DragSelectTouchListener
import com.applock.lock.apps.fingerprint.password.view.DragSelectionProcessor
import com.applock.lock.apps.fingerprint.password.view.DragSelectionProcessor.ISelectionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream


class FileListActivity : AppCompatActivity(), FileListAdapter.OnItemClickListener {
    private val TAG = "FileListActivity++++++"

    private lateinit var binding: ActivityFileListBinding

    private val mMode: DragSelectionProcessor.Mode = DragSelectionProcessor.Mode.Simple
    private var mDragSelectTouchListener: DragSelectTouchListener? = null

    private var mDragSelectionProcessor: DragSelectionProcessor? = null
    var adapter: FileListAdapter? = null


    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFileListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        getIntentData(intent)
        clickListners()
    }

    private fun clickListners() {
        binding.ivBack.setOnClickListener {
            if (adapter?.getCountSelected()!! > 0) {
                adapter?.deselectAll()
                binding.btnHideFile.gone()

            } else {
                onBackPressed()
            }
        }
        binding.tvSelectAll.setOnClickListener {
            adapter?.selectAll()
        }
        binding.btnHideFile.setOnClickListener {
            selectedItemsList = adapter?.getSelectedItems() ?: arrayListOf()
            Log.d(
                TAG,
                "selectedItemsListSize-----${selectedItemsList.size}"
            )
            Log.d(
                TAG,
                "selectedItemsListAt 0-----${selectedItemsList.get(0).filePath}"
            )
            if (isFromVault) {

                val intent = Intent(this@FileListActivity, VideoPreviewActivity::class.java)
                intent.putExtra("path", selectedItemsList.get(0).filePath)
                startActivity(intent)
                onBackPressed()

         /*
                val intent = Intent(this@FileListActivity, VaultPreviewActivity::class.java)
                intent.putExtra("path", selectedItemsList.get(0).filePath)
                startActivity(intent)
                onBackPressed()*/
            } else {
                if (type == PHOTO_TYPE) {
                    hidePhoto()
                }
                if (type == VIDEO_TYPE) {
                    hideVideo()
                }
                if (type == AUDIO_TYPE) {
                    hideAudio()
                }
                if (type == FILE_TYPE) {
                    hideFile()
                }
            }

        }
    }



    private fun getIntentData(intent: Intent?) {
        isFromVault = intent?.getBooleanExtra(IS_FROM_VAULT, false)!!
        type = intent.getStringExtra(TYPE)!!

        if (isFromVault) {
            binding.btnHideFile.text = "UnHide"
        } else {
            binding.btnHideFile.text = "Hide"

        }

        receivedFilesData = if (!isFromVault) {
            ArrayList(FolderListActivity.selectedImages!!)

        } else {

            if (type == PHOTO_TYPE) {
                ArrayList(VaultFragment.itemImageFolderClickList!!)

            } else if (type == VIDEO_TYPE) {
                ArrayList(VaultFragment.itemVideoFolderClickList!!)

            } else if (type == AUDIO_TYPE) {
                ArrayList(VaultFragment.itemAudioFolderClickList!!)

            } else
                ArrayList(VaultFragment.itemFileFolderClickList!!)


        }

        setFileListRecyclerView(receivedFilesData)
    }

    private fun setFileListRecyclerView(receivedFilesData: ArrayList<MediaFile>) {
        adapter = FileListAdapter(this@FileListActivity, receivedFilesData, type)
        binding.rvFileList.adapter = adapter
        adapter!!.setOnItemClickListener(this)

        // Add the DragSelectListener
        mDragSelectionProcessor = DragSelectionProcessor(object : ISelectionHandler {
            override val selection: Set<Int>
                get() = adapter!!.getSelection()

            override fun isSelected(index: Int): Boolean {
                return adapter!!.getSelection().contains(index)
            }

            override fun updateSelection(
                start: Int,
                end: Int,
                isSelected: Boolean,
                calledFromOnStart: Boolean
            ) {
                adapter!!.selectRange(start, end, isSelected)
            }
        }).withMode(mMode)
        mDragSelectTouchListener =
            DragSelectTouchListener().withSelectListener(mDragSelectionProcessor)
        updateSelectionListener()
        binding.rvFileList.addOnItemTouchListener(mDragSelectTouchListener!!)

    }

    private fun updateSelectionListener() {
        mDragSelectionProcessor!!.withMode(mMode)
        Log.d(TAG, "updateSelectionListener-------: ${mMode.name}")
    }

    override fun onFileItemClick(position: Int, mediaFile: MediaFile) {
        if (adapter != null) {
            adapter!!.toggleSelection(position)
        }
    }

    override fun onItemLongClick(view: View?, position: Int, mediaFile: MediaFile): Boolean {
        mDragSelectTouchListener!!.startDragSelection(position)
        return true
    }

    override fun onSelectionCountChanged(selectedCount: Int) {

        if (isFromVault) {
            binding.btnHideFile.text = "UnHide ${selectedCount}"
        } else {
            binding.btnHideFile.text = "Hide ${selectedCount}"
        }
        if (selectedCount > 0) {
            binding.btnHideFile.visible()

        } else {
            binding.btnHideFile.gone()
        }
    }

    private fun hidePhoto() {

        createImageDirAboveQ()
        startProgressActivity(PHOTO_TYPE)

    }

    private fun hideVideo() {
        createVideoDirAboveQ()
        startProgressActivity(VIDEO_TYPE)

    }

    private fun hideAudio() {
        createAudioDirAboveQ()
        startProgressActivity(AUDIO_TYPE)

    }

    private fun hideFile() {
        createFileDirAboveQ()
        startProgressActivity(FILE_TYPE)

    }

    private val imagePermissionForQ: Unit
        private get() {

            createImageDirAboveQ()
            startProgressActivity(PHOTO_TYPE)

        }
    private val audioPermissionForQ: Unit
        private get() {

            createAudioDirAboveQ()
            startProgressActivity(AUDIO_TYPE)

        }

    private val filePermissionForQ: Unit
        private get() {

            createFileDirAboveQ()
            startProgressActivity(FILE_TYPE)

        }

    private val videoPermissionForQ: Unit
        private get() {
            createVideoDirAboveQ()
            startProgressActivity(VIDEO_TYPE)

        }

    @Throws(IOException::class)
    private fun copyFile(src: File, dst: File): Boolean {
        if (src.absolutePath.toString()
            == dst.absolutePath.toString()
        ) {
            return true
        } else {
            val `is`: InputStream = FileInputStream(src)
            val os: OutputStream = FileOutputStream(dst)
            val buff = ByteArray(1024)
            var len: Int
            while (`is`.read(buff).also { len = it } > 0) {
                os.write(buff, 0, len)
            }
            `is`.close()
            os.close()
        }
        return true
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            Log.d(
                TAG,
                "-----onActivityResult-----"
            )

            if (requestCode == REQUEST_HIDE_PHOTOS) {
                if (data!!.data != null) {
                    val treeUri = data.data
                    putImageHideUri(treeUri.toString(), this)
                    hidePhoto()
                }
            }
            if (requestCode == REQUEST_HIDE_VIDEOS) {
                if (data!!.data != null) {
                    val treeUri = data.data
                    putVideoHideUri(treeUri.toString(), this)
                    hideVideo()
                }
            }

            if (requestCode == REQUEST_HIDE_AUDIOS) {
                if (data!!.data != null) {
                    val treeUri = data.data
                    putAudioHideUri(treeUri.toString(), this)
                    hideAudio()
                }
            }

            if (requestCode == REQUEST_HIDE_FILES) {
                if (data!!.data != null) {
                    val treeUri = data.data
                    putFileHideUri(treeUri.toString(), this)
                    hideFile()
                }
            }


            if (requestCode == REQUEST_CODE_HIDE_PROGRESS) {
                Log.d(TAG, "-----REQUEST_CODE_HIDE_PROGRESS-------")
                Log.d(TAG, "-----HideType-------$type")

                if (type == PHOTO_TYPE) {
                    VaultFragment.fragmentScope.launch {

                        VaultFragment.getImagesList(this@FileListActivity, false)
                        VaultFragment.getHiddenPhotos(this@FileListActivity, false, false)
                        VaultFragment.catPhotoSelected(this@FileListActivity)
                    }
                }
                if (type == VIDEO_TYPE) {

                    VaultFragment.fragmentScope.launch {
                        VaultFragment.getVideosList(this@FileListActivity, false)
                        VaultFragment.getHiddenVideos(this@FileListActivity, false, false)
                        VaultFragment.catVideoSelected(this@FileListActivity)
                    }
                }
                if (type == AUDIO_TYPE) {
                    VaultFragment.fragmentScope.launch(Dispatchers.IO) {
                        VaultFragment.getAudioFiles(this@FileListActivity, false)
                        VaultFragment.getHiddenAudios(this@FileListActivity, false, false)
                        VaultFragment.catAudioSelected(this@FileListActivity)

                    }
                }
                if (type == FILE_TYPE) {
                    VaultFragment.fragmentScope.launch(Dispatchers.IO) {
                        VaultFragment.getDocumentFilesList(this@FileListActivity, false)
                        VaultFragment.getHiddenDocumentFiles(this@FileListActivity, false, false)
                        VaultFragment.catFileSelected(this@FileListActivity)
                    }
                }

                // Remove selected items from the original list
                receivedFilesData.removeAll(selectedItemsList)
                setFileListRecyclerView(receivedFilesData)
                adapter?.notifyDataSetChanged()
                onBackPressed()
            }

        }

    }

    private fun startProgressActivity(hideType: String) {

        Log.d(
            TAG,
            "selectedItemsList---Size()--${selectedItemsList.get(0).fileName}----${
                selectedItemsList.get(
                    0
                ).filePath
            }"
        )


        if (!selectedItemsList.isNullOrEmpty()) {
            val intent = Intent(this, HideFileActivity::class.java)
            intent.putExtra(INTENT_HIDETYPE, hideType)
            startActivityForResult(intent, REQUEST_CODE_HIDE_PROGRESS)
        }
    }

    private fun createVideoDirAboveQ() {
        val dir = File(VIDEO_SDCARD_PATH_ABOVE_Q)
        if (dir.exists() && dir.isDirectory) {
            Log.d(TAG, "VideoDir ABOVE_Q Directory exist")

        } else {
            try {
                if (dir.mkdirs()) {
                    Log.d(TAG, "VideoDir ABOVE_Q Directory Created")

                } else {
                    Log.d(TAG, "VideoDir ABOVE_Q Directory Not Created")


                }
            } catch (e: Exception) {
                Log.d(TAG, "VideoDir Exception---" + e.message)

            }
        }
    }


    fun createImageDirAboveQ() {
        val dir = File(PHOTO_SDCARD_PATH_ABOVE_Q)
        if (dir.exists() && dir.isDirectory) {
            Log.d(TAG, "ImageABOVE_Q Directory exist")
        } else {
            try {
                if (dir.mkdirs()) {
                    Log.d(TAG, "ImageDir ABOVE_Q  Created")
                } else {
                    Log.d(TAG, "ImageDir ABOVE_Q Not Created")
                }
                MediaScannerConnection.scanFile(
                    this@FileListActivity, arrayOf<String>(dir.absolutePath), null
                ) { str: String?, uri: Uri? ->

                }
            } catch (e: Exception) {
                Log.e(TAG, "ImageDir Exception-----" + e.message)
            }
        }
    }


    fun createFileDirAboveQ() {
        val dir = File(FILE_SDCARD_PATH_ABOVE_Q)
        if (dir.exists() && dir.isDirectory) {
            Log.d(TAG, "FileDir ABOVE_Q Directory exist")

        } else {
            try {
                if (dir.mkdirs()) {
                    Log.d(TAG, "FileDir ABOVE_Q  Created")

                } else {
                    Log.d(TAG, "FileDir ABOVE_Q not Created")

                }
            } catch (e: Exception) {
                Log.e(TAG, "FileDir Exception---" + e.message)

            }
        }
    }


    fun createAudioDirAboveQ() {
        val dir = File(AUDIO_SDCARD_PATH_ABOVE_Q)
        if (dir.exists() && dir.isDirectory) {
            Log.d(TAG, "AudioDir ABOVE_Q Directory exist")

        } else {
            try {
                if (dir.mkdirs()) {
                    Log.d(TAG, "AudioDir ABOVE_Q  Created")
                } else {
                    Log.d(TAG, "AudioDir ABOVE_Q  not Created")
                }
            } catch (e: Exception) {
                Log.d(TAG, "AudioDir Exception----" + e.message)
            }
        }
    }


    companion object {
        lateinit var selectedItemsList: ArrayList<MediaFile>
        var count = 0
        private lateinit var receivedFilesData: ArrayList<MediaFile>

        private val REQUEST_CODE_HIDE_PROGRESS = 101
        var loading: ProgressDialog? = null
        var type = PHOTO_TYPE
        var isFromVault = false

    }

}