package com.applock.lock.apps.fingerprint.password.activity

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.app.AppOpsManager.OnOpChangedListener
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.PersistableBundle
import android.os.Process
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.databinding.ActivityCalldoradoPermissionBinding
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener


class AppPermissionActivity : AppCompatActivity() {
    var binding: ActivityCalldoradoPermissionBinding? = null
    var permissionCheckLauncher: ActivityResultLauncher<Intent>? = null
    var managePermissionCheckLauncher: ActivityResultLauncher<Intent>? = null
    private var isBackPressedOff = false

    private var tabChangeHandler: Handler? = null

    //int count = 0;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.primaryColor));
        binding = ActivityCalldoradoPermissionBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        initView()
    }

    private fun initView() {
        permissionCheckLauncher = registerForActivityResult<Intent, ActivityResult>(
            ActivityResultContracts.StartActivityForResult()
        ) { result: ActivityResult? ->
            if (result != null && result.resultCode == RESULT_OK) {
                askOverlayPermission()
            } else {
                Toast.makeText(this, "Permission is required", Toast.LENGTH_SHORT).show()
            }
        }
        managePermissionCheckLauncher = registerForActivityResult<Intent, ActivityResult>(
            ActivityResultContracts.StartActivityForResult()
        ) { result: ActivityResult? ->
            if (result != null && result.resultCode == Activity.RESULT_OK) {
                // Permission is allowed, perform further actions here
                checkExternalStoragePermission()
            } else {
                Toast.makeText(this, "Permission is required", Toast.LENGTH_SHORT).show()
            }
        }
        binding!!.groupNotification.visibility = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) View.VISIBLE else View.GONE
        binding!!.btnGrantPermission.setOnClickListener { askCallerSdkPermission() }
    }
    // Function to check if the permission for managing external storage is granted
    private fun checkExternalStoragePermission() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
        {
            if (Environment.isExternalStorageManager()) {
                navigateToMainScreen()
            //   askOverlayPermission()

            } else {
                Toast.makeText(this, "Permission not granted", Toast.LENGTH_SHORT).show()
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            if (Environment.isExternalStorageManager()) {
                navigateToMainScreen()
              //  askOverlayPermission()

            } else {
                // Permission is not granted
                Toast.makeText(this, "Permission not granted", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun askCallerSdkPermission()
    {
        val allPermissions: Array<String> =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            {
                arrayOf(
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.CAMERA,
                    Manifest.permission.POST_NOTIFICATIONS
                )
            }
            else
            {
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA
                )
            }




/*
        val additionalPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            arrayOf(Manifest.permission.MANAGE_EXTERNAL_STORAGE)
        } else {
            arrayOf()
        }

        val combinedPermissions = allPermissions + additionalPermissions
*/


        Dexter.withContext(this)
            .withPermissions(*allPermissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(multiplePermissionsReport: MultiplePermissionsReport) {
                    //multiplePermissionsReport.areAllPermissionsGranted()
                    var isNecessaryPermissionGranted = false
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    {
                        isNecessaryPermissionGranted =
                            ActivityCompat.checkSelfPermission(this@AppPermissionActivity, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED &&
                                    ActivityCompat.checkSelfPermission(this@AppPermissionActivity, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED &&
                                    ActivityCompat.checkSelfPermission(this@AppPermissionActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                                    ActivityCompat.checkSelfPermission(this@AppPermissionActivity, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                                   // && ActivityCompat.checkSelfPermission(this@AppPermissionActivity, Manifest.permission.MANAGE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                    }
                    else
                    {
                        for (permission in allPermissions)
                        {
                            if (ActivityCompat.checkSelfPermission(
                                    this@AppPermissionActivity,
                                    permission
                                ) == PackageManager.PERMISSION_GRANTED
                            )
                            {
                                isNecessaryPermissionGranted = true
                            }
                            else
                            {
                                isNecessaryPermissionGranted = false
                                break
                            }
                        }
                    }
                    if (isNecessaryPermissionGranted)
                    {
                        askOverlayPermission()
                    }
                    else if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied)
                    {
                        Toast.makeText(this@AppPermissionActivity, getString(R.string.permission_denied_msg), Toast.LENGTH_LONG).show()
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        val uri = Uri.fromParts("package", applicationContext.packageName, null)
                        intent.data = uri
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        permissionCheckLauncher!!.launch(intent)
                    }
                    else
                    {
                        Toast.makeText(
                            this@AppPermissionActivity,
                            "Permission is required.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    list: List<PermissionRequest>,
                    permissionToken: PermissionToken
                ) {
                    permissionToken.continuePermissionRequest()
                }
            }).check()



    }

    fun askOverlayPermission() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
    {
        if (!Settings.canDrawOverlays(this)) {
            val appOps = getSystemService(APP_OPS_SERVICE) as AppOpsManager
            val mode = appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW, Process.myUid(),
                packageName
            )
            if (mode == AppOpsManager.MODE_ALLOWED) {
                checkCallerSDkPermission()
            }
            appOps.startWatchingMode(
                AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW,
                applicationContext.packageName,
                object : OnOpChangedListener {
                    override fun onOpChanged(op: String, packageName: String) {
                        val mode = appOps.checkOpNoThrow(
                            AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW,
                            Process.myUid(),
                            getPackageName()
                        )
                        if (mode != AppOpsManager.MODE_ALLOWED) {
                            return
                        }
                        isBackPressedOff = true
                        appOps.stopWatchingMode(this)
                        val intent = intent
                        overridePendingTransition(0, 0)
                        intent.flags = Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        finish()
                        overridePendingTransition(0, 0)
                        startActivity(intent)
                        checkCallerSDkPermission()
                    }
                })
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + applicationContext.packageName)
                )
                startActivityForResult(intent, 1)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {

    showNextScreen()
        }
    } else {
        showNextScreen()
    }


    fun checkCallerSDkPermission() {
        onBoardingSuccess()
    }

    private fun onBoardingSuccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(this@AppPermissionActivity)) {
                showNextScreen()
            } else Toast.makeText(this, "Overlay permission is require", Toast.LENGTH_SHORT).show()
        } else {
            showNextScreen()
        }
    }

    override fun onBackPressed() {
        if (!isBackPressedOff)
            super.onBackPressed()
    }

    private fun showNextScreen() {
        appManageFilePermission()
      //  navigateToMainScreen()


      //  navigateToMainScreen()
  /*      if (!PreferenceManager.getInstance(this@CalldoradoPermissionActivity)
                .isLanguageSelected()
        ) {
            navigateToLanguageScreen()
        } else {
            navigateToMainScreen()
        }*/
    }

    fun appManageFilePermission()
    {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
        {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            {
                if (Environment.isExternalStorageManager()) {
                    navigateToMainScreen()

                } else {
                    val intent =
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    val uri =
                        Uri.fromParts("package", packageName, null)
                    intent.data = uri
                    // Start the permission request using the launcher
                    managePermissionCheckLauncher?.launch(intent)
                  //  startActivity(intent)
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                if (Environment.isExternalStorageManager()) {
                    navigateToMainScreen()
                } else {
                    val intent =
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    val uri =
                        Uri.fromParts("package", packageName, null)
                    intent.data = uri
                    // Start the permission request using the launcher
                    managePermissionCheckLauncher?.launch(intent)
                 //   startActivity(intent)
                }
            }
        }else{
            navigateToMainScreen()
        }

    }


    private fun navigateToLanguageScreen() {
        // startActivity(Intent(this@CalldoradoPermissionActivity, LanguageActivity::class.java))
        finish()
    }


    private fun navigateToMainScreen() {
      //  startActivity(Intent(this@AppPermissionActivity, MainActivity::class.java))
        startActivity(Intent(this@AppPermissionActivity, FirstActivity::class.java))
        finish()
    }

    override fun onDestroy() {

        super.onDestroy()
        if (tabChangeHandler != null) tabChangeHandler!!.removeCallbacksAndMessages(null)
    }
}
