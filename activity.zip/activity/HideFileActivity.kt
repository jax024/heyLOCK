package com.applock.lock.apps.fingerprint.password.activity

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.applock.lock.apps.fingerprint.password.databinding.ActivityHideProcessBinding
import com.applock.lock.apps.fingerprint.password.navigation.vault.MediaFile
import com.applock.lock.apps.fingerprint.password.utils.AUDIOS_COUNT
import com.applock.lock.apps.fingerprint.password.utils.AUDIO_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.AUDIO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.FILES_COUNT
import com.applock.lock.apps.fingerprint.password.utils.FILE_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.FILE_TYPE
import com.applock.lock.apps.fingerprint.password.utils.INTENT_HIDETYPE
import com.applock.lock.apps.fingerprint.password.utils.INTENT_SELECTED_IMAGES
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_COUNT
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.PHOTO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.VIDEOS_COUNT
import com.applock.lock.apps.fingerprint.password.utils.VIDEO_SDCARD_PATH_ABOVE_Q
import com.applock.lock.apps.fingerprint.password.utils.VIDEO_TYPE
import com.applock.lock.apps.fingerprint.password.utils.saveIntegerToUserDefaults
import com.applock.lock.apps.fingerprint.password.utils.visible
import com.applock.lock.apps.fingerprint.password.view.MediaDB
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.regex.Matcher
import java.util.regex.Pattern

class HideFileActivity : AppCompatActivity() {
    private val TAG = "HideProgressActivity++++++"

    private lateinit var binding: ActivityHideProcessBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHideProcessBinding.inflate(layoutInflater)
        setContentView(binding.root)
        getIntentData(intent)
        clickListners()
    }

    private fun clickListners() {
        binding.btnOK.setOnClickListener {
            val resultIntent = Intent()
            resultIntent.putExtra(INTENT_HIDETYPE, hideType) // Replace "key" and "value" with your data
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun getIntentData(intent: Intent?) {
        selectedItemsList = FileListActivity.selectedItemsList
        hideType = intent!!.getStringExtra(INTENT_HIDETYPE)!!
        Log.d(
            TAG,
            "hideType-----${hideType}"
        )
        if (selectedItemsList != null) {
            Log.d(
                TAG,
                "selectedItemsList---Size()--${selectedItemsList.size}"
            )
            if (hideType == PHOTO_TYPE) {

                GlobalScope.launch(Dispatchers.IO) {
                    lockImages()
                }
            }
            if (hideType == VIDEO_TYPE) {
                GlobalScope.launch(Dispatchers.IO) {
                    lockVideos()
                }
            }
            if (hideType == AUDIO_TYPE) {
                GlobalScope.launch(Dispatchers.IO) {
                    lockAudios()
                }
            }
            if (hideType == FILE_TYPE) {

                GlobalScope.launch(Dispatchers.IO) {
                    lockFiles()
                }
            }

        } else {
            Log.d(
                TAG,
                "receivedData-----null"
            )
        }
    }

    @SuppressLint("SetTextI18n")
    private suspend fun lockImages()
    {
        Log.d(TAG, "LOCK_IMAGE----onPreExecute---")
        runOnUiThread {
            // Update UI on the main thread
            binding.tvHide.text = "Encrypt data... "
        }

        Log.d(TAG, "LOCK_IMAGE----doInBackground---")

        val deleteFiles = ArrayList<String>()
        val totalFilesToMove = selectedItemsList.size
        var filesmoved = 0
        val db = MediaDB(this@HideFileActivity)
        db.open()

        for (i in selectedItemsList.indices)
        {
            val fileinDirectory = File(selectedItemsList[i].filePath)

            val folderName = selectedItemsList[i].filePath.substringBeforeLast("/").substringAfterLast("/")
            if ('.' in folderName) {
                folderName.replace(".", "")
            }

           val PHOTO_SDCARD_PATH_ABOVE_Q = PHOTO_SDCARD_PATH_ABOVE_Q+folderName+"/"
            Log.d(TAG, "LOCK_IMAGE----_DIRECTORY_PATH: $PHOTO_SDCARD_PATH_ABOVE_Q")

                if (!File(PHOTO_SDCARD_PATH_ABOVE_Q).exists()) {
                    File(PHOTO_SDCARD_PATH_ABOVE_Q).mkdirs()
                }

            Log.d(
                TAG,
                "LOCK_IMAGE----File(PHOTO_DIRECTORY_PATH).mkdirs(): ${File(PHOTO_SDCARD_PATH_ABOVE_Q).exists()}"
            )


            Log.d(TAG, "LOCK_IMAGE-----fileinDirectory.name----${fileinDirectory.name}")
            Log.d(TAG, "LOCK_IMAGE-----fileinDirectory.path----${fileinDirectory.path}")


            var newfilee = File(PHOTO_SDCARD_PATH_ABOVE_Q + fileinDirectory.name)

            Log.d(TAG, "LOCK_IMAGE----new path---${newfilee.path}")

            val isRenamedImage = fileinDirectory.renameTo(newfilee)

            Log.d(TAG, "LOCK_IMAGE-----isRenamedImage--?----${isRenamedImage}")


            db.insertImage(fileinDirectory.name, fileinDirectory.path)

            if (fileinDirectory.exists()) {
                Log.e(TAG, "Fail to DELETE ImageFile----$i--->$fileinDirectory")
            } else {
                Log.d(TAG, "DELETED ImageFile at index----$i--->$fileinDirectory")
            }

            count++
            saveIntegerToUserDefaults(applicationContext, PHOTO_COUNT, count)

            filesmoved += 1

            // Update progress
            runOnUiThread {
                binding.tvHide.text = "$filesmoved/$totalFilesToMove   Encrypt Image... "
            }

        }

        // Scan the storage
        MediaScannerConnection.scanFile(
            this@HideFileActivity,
            arrayOf<String>(Environment.getExternalStorageDirectory().absolutePath),
            null
        ) { _: String?, _: Uri? -> }

        // Update UI when finished
        runOnUiThread {
            binding.tvHide.text = "Hide successfully"
            binding.btnOK.visible()
        }
    }

    @SuppressLint("SetTextI18n")
    private suspend fun lockVideos() {
        Log.d(TAG, "LOCK_VIDEO----onPreExecute---")
        runOnUiThread {
            // Update UI on the main thread
            binding.tvHide.text = "Encrypt data... "
        }

        val deleteFiles = ArrayList<String>()
        val totalFilesToMove = selectedItemsList.size
        var filesmoved = 0
        val db = MediaDB(this@HideFileActivity)
        db.open()

        for (i in selectedItemsList.indices)
        {
            val fileinDirectory = File(selectedItemsList[i].filePath)

            val folderName = selectedItemsList[i].filePath.substringBeforeLast("/").substringAfterLast("/")
            if ('.' in folderName) {
                folderName.replace(".", "")
            }

           val VIDEO_SDCARD_PATH_ABOVE_Q = VIDEO_SDCARD_PATH_ABOVE_Q+folderName+"/"

            if (!File(VIDEO_SDCARD_PATH_ABOVE_Q).exists()) {
                File(VIDEO_SDCARD_PATH_ABOVE_Q).mkdirs()
            }

            Log.d(
                TAG,
                "LOCK_VIDEO--------File(VIDEO_SDCARD_PATH_ABOVE_Q).mkdirs(): ${
                    File(
                        VIDEO_SDCARD_PATH_ABOVE_Q
                    ).exists()
                }"
            )
            Log.d(TAG, "LOCK_VIDEO-----fileinDirectory.name----${fileinDirectory.name}")
            Log.d(TAG, "LOCK_VIDEO-----fileinDirectory.path----${fileinDirectory.path}")


            val newfilee = File(VIDEO_SDCARD_PATH_ABOVE_Q + fileinDirectory.name)
            Log.d(TAG, "LOCK_VIDEO----new path---${newfilee.path}")

            val isRenamedVideo = fileinDirectory.renameTo(newfilee)
            Log.d(TAG, "LOCK_VIDEO-----isRenamedVideo--?----${isRenamedVideo}")

            db.insertVideo(fileinDirectory.name, fileinDirectory.path)

            if (fileinDirectory.exists()) {
                Log.e(TAG, "Fail to DELETE VideoFile----$i--->$fileinDirectory")
            } else {
                Log.d(TAG, "DELETED VideoFile at index----$i--->$fileinDirectory")
            }

            count++
            saveIntegerToUserDefaults(applicationContext, VIDEOS_COUNT, count)

            filesmoved += 1

            // Update progress
            runOnUiThread {
                binding.tvHide.text = "$filesmoved/$totalFilesToMove   Encrypt Videos... "
            }
        }

        // Scan the storage
        MediaScannerConnection.scanFile(
            this@HideFileActivity,
            arrayOf<String>(Environment.getExternalStorageDirectory().absolutePath),
            null
        ) { str: String?, uri: Uri? ->

        }

        // Update UI when finished
        runOnUiThread {
            binding.tvHide.text = "Hide successfully"
            binding.btnOK.visible()
        }
    }

    @SuppressLint("SuspiciousIndentation")
    private suspend fun lockAudios() {
        Log.d(TAG, "LOCK_AUDIO----onPreExecute---")
        runOnUiThread {
            // Update UI on the main thread
            binding.tvHide.text = "Encrypt data... "
        }

        Log.d(TAG, "LOCK_AUDIO----doInBackground---")

        val deleteFiles = ArrayList<String>()
        val totalFilesToMove = selectedItemsList.size
        var filesmoved = 0
        val db = MediaDB(this@HideFileActivity)
        db.open()

        for (i in selectedItemsList.indices) {
            val fileinDirectory = File(selectedItemsList[i].filePath)


            val folderName = selectedItemsList[i].filePath.substringBeforeLast("/").substringAfterLast("/")
            if ('.' in folderName) {
                folderName.replace(".", "")
            }

          val  AUDIO_SDCARD_PATH_ABOVE_Q = AUDIO_SDCARD_PATH_ABOVE_Q+folderName+"/"


            if (!File(AUDIO_SDCARD_PATH_ABOVE_Q).exists()) {
                File(AUDIO_SDCARD_PATH_ABOVE_Q).mkdirs()
            }
            Log.d(
                TAG,
                "LOCK_AUDIO--------File(AUDIO_SDCARD_PATH_ABOVE_Q).mkdirs(): ${
                    File(AUDIO_SDCARD_PATH_ABOVE_Q).exists()
                }"
            )
            Log.d(TAG, "LOCK_AUDIO-----fileinDirectory.name----${fileinDirectory.name}")
            Log.d(TAG, "LOCK_AUDIO-----fileinDirectory.name----${fileinDirectory.path}")

            val newfilee = File(AUDIO_SDCARD_PATH_ABOVE_Q + fileinDirectory.name)
            Log.d(TAG, "LOCK_AUDIO----new path---${newfilee.path}")

            val isRenamedAudio = fileinDirectory.renameTo(newfilee)
            Log.d(TAG, "LOCK_AUDIO-----isRenamedAudio--?----${isRenamedAudio}")

            db.insertAudio(fileinDirectory.name, fileinDirectory.path)

            if (fileinDirectory.exists()) {
                Log.e(TAG, "Fail to DELETE AudioFile----$i--->$fileinDirectory")
            } else {
                Log.d(TAG, "DELETED AudioFile at index----$i--->$fileinDirectory")
            }

            count++
            saveIntegerToUserDefaults(applicationContext, AUDIOS_COUNT, count)

            filesmoved += 1

            // Update progress
            runOnUiThread {
                binding.tvHide.text = "$filesmoved/$totalFilesToMove   Encrypt Audios... "
            }

        }

        // Scan the storage
        MediaScannerConnection.scanFile(
            this@HideFileActivity,
            arrayOf<String>(Environment.getExternalStorageDirectory().absolutePath),
            null
        ) { str: String?, uri: Uri? ->

        }

        // Update UI when finished
        runOnUiThread {
            binding.tvHide.text = "Hide Successfully"
            binding.btnOK.visible()
        }
    }


    private suspend fun lockFiles()
    {
        //NOTE:  here FileName is FolderPath and Folder is FileName----
        Log.d(TAG, "LOCK_FILE----onPreExecute---")
        runOnUiThread {
            // Update UI on the main thread
            binding.tvHide.text = "Encrypt data... "
        }

        Log.d(TAG, "LOCK_FILE----doInBackground---")

        val deleteFiles = ArrayList<String>()
        val totalFilesToMove = selectedItemsList.size
        var filesmoved = 0
        val db = MediaDB(this@HideFileActivity)
        db.open()

        for (i in selectedItemsList.indices)
        {
            
          //+  val fileinDirectory = File(selectedItemsList[i].filePath)
            val fileinDirectory = File(selectedItemsList[i].fileName)
            Log.d(TAG, "LOCK_FILE----original path---${File(selectedItemsList[i].fileName)}")


            val folderName = selectedItemsList[i].fileName.substringBeforeLast("/").substringAfterLast("/")
            if ('.' in folderName) {
                folderName.replace(".", "")
            }
            Log.d(TAG, "LOCK_FILE----folderName---${folderName}")

         val  FILE_SDCARD_PATH_ABOVE_Q = FILE_SDCARD_PATH_ABOVE_Q+folderName+"/"

            if (!File(FILE_SDCARD_PATH_ABOVE_Q).exists()) {
                File(FILE_SDCARD_PATH_ABOVE_Q).mkdirs()
            }

            Log.d(
                TAG,
                "LOCK_FILE--------File(FILE_SDCARD_PATH_ABOVE_Q).mkdirs(): ${
                    File(FILE_SDCARD_PATH_ABOVE_Q).exists()
                }"
            )
            Log.d(TAG, "LOCK_FILE----fileinDirectory.name----${fileinDirectory.name}")
            Log.d(TAG, "LOCK_FILE----fileinDirectory.path----${fileinDirectory.path}")

          //  val newfilee = File(FILE_SDCARD_PATH_ABOVE_Q + fileinDirectory.name)
            val newfilee = File(FILE_SDCARD_PATH_ABOVE_Q + File(selectedItemsList[i].filePath))

            Log.d(TAG, "LOCK_FILE----new path---${newfilee.path}")


            val isRenamedFile = fileinDirectory.renameTo(newfilee)

            Log.d(TAG, "LOCK_FILE----isRenamedFile--?----${isRenamedFile}")


            db.insertFile(fileinDirectory.name, fileinDirectory.path)
           // db.insertFile(fileinDirectory.name, File(selectedItemsList[i].fileName).absolutePath)

            if (fileinDirectory.exists()) {
                Log.e(TAG, "Fail to DELETE DocumentFile----$i--->$fileinDirectory")
            } else {
                Log.d(TAG, "DELETED DocumentFile at index----$i--->$fileinDirectory")
            }

            count++
            saveIntegerToUserDefaults(applicationContext, FILES_COUNT, count)

            filesmoved += 1

            // Update progress
            runOnUiThread {
                binding.tvHide.text = "$filesmoved/$totalFilesToMove   Encrypt Files... "
            }

        }

        // Scan the storage
        MediaScannerConnection.scanFile(
            this@HideFileActivity,
            arrayOf<String>(Environment.getExternalStorageDirectory().absolutePath),
            null
        ) { str: String?, uri: Uri? ->

        }

        // Update UI when finished
        runOnUiThread {
            binding.tvHide.text = "Hide successfully"
            binding.btnOK.visible()
        }
    }

    companion object {
        private lateinit var selectedItemsList: ArrayList<MediaFile>
        private lateinit var hideType: String
        var count = 0
    }

}