package com.applock.lock.apps.fingerprint.password.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.DecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import com.applock.lock.apps.fingerprint.password.databinding.SplashActivityBinding


class SplashActivity : AppCompatActivity() {
    var binding: SplashActivityBinding? = null
    private val TAG = "SplashActivity+++++++"

    @SuppressLint("SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = SplashActivityBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        Init()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        if (!hasFocus) {
            return
        }
        animate()
        super.onWindowFocusChanged(hasFocus)
    }

    private fun Init() {
        navigateToMainScreen()
    }

    private fun navigateToMainScreen() {
        Handler(Looper.myLooper()!!).postDelayed({
            startActivity(Intent(this@SplashActivity, OnBoardingActivity::class.java))
            finish()
        }, 5000)
    }

    private fun animate() {
        ViewCompat.animate(binding!!.ivLogo)
            .translationY(-50f)
            .scaleYBy(-0.1f).scaleXBy(-0.1f)
            .setStartDelay(STARTUP_DELAY.toLong())
            .setDuration(ANIM_ITEM_DURATION.toLong()).setInterpolator(DecelerateInterpolator(1.2f))
            .start()
        ViewCompat.animate(binding!!.tvSplashLabel)
            .translationY(-70f)
            .scaleYBy(0.3f).scaleXBy(0.3f)
            .alpha(1f)
            .setStartDelay((STARTUP_DELAY + 100).toLong())
            .setDuration(ANIM_ITEM_DURATION.toLong()).setInterpolator(
                DecelerateInterpolator(1.2f)
            ).start()
    }

    companion object {
        const val REQUEST_PERMISSION = 100
        const val STARTUP_DELAY = 0
        const val ANIM_ITEM_DURATION = 1000
    }

}