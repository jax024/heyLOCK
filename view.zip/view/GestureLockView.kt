package com.applock.lock.apps.fingerprint.password.view

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.gesture.Gesture
import android.gesture.GestureLibraries
import android.gesture.GestureLibrary
import android.gesture.GestureOverlayView
import android.gesture.GestureOverlayView.OnGesturePerformedListener
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.ContextThemeWrapper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.SurfaceView
import android.view.View
import android.view.View.OnClickListener
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.activity.MainActivity
import com.applock.lock.apps.fingerprint.password.utils.CameraFuncation
import com.applock.lock.apps.fingerprint.password.utils.ConnectionDetector
import com.applock.lock.apps.fingerprint.password.utils.DIGIT_BG
import com.applock.lock.apps.fingerprint.password.utils.SECURITY_ANSWER
import com.applock.lock.apps.fingerprint.password.utils.ServicePreference
import com.applock.lock.apps.fingerprint.password.utils.THEME_TYPE
import com.applock.lock.apps.fingerprint.password.utils.getBitmap
import com.applock.lock.apps.fingerprint.password.utils.getFromUserDefaults
import com.applock.lock.apps.fingerprint.password.utils.getThemeType

class GestureLockView(
    context: Context?,
    var datas: String?,
    attrs: AttributeSet?,
    var listener: LockCloseListener?
) : RelativeLayout(context, attrs) {
    var applicationContext: Context? = null
    var view: View? = null
    lateinit var mLibrary: GestureLibrary
    var gestures: GestureOverlayView? = null
    var isCorrectPasswordEntered = false
    var rootview: LinearLayout? = null

    //ImageView ivpopup;
    var img_dot: ImageView? = null
    var isInternetPresent = false
    var cd: ConnectionDetector? = null
    var icon: Drawable? = null
    var packagename: String? = null
    var shakeanimation: Animation? = null
    var passwordTry = 0
    var from_app = false
    var count = 0
    lateinit var lout_toast: CardView
    lateinit var txt_toast_msg: TextView
    lateinit var lout_forgot_dialog: RelativeLayout
    var Onclick = OnClickListener { v: View? -> }
    lateinit var cameraFuncation: CameraFuncation
    private var surfaceView: SurfaceView? = null

    interface LockCloseListener {
        fun onCloseLock()
        fun onBackCloseLock()
    }

    fun showToast(msg: String?) {
        txt_toast_msg!!.text = msg
        lout_toast!!.visibility = VISIBLE
        Handler(Looper.myLooper()!!).postDelayed({ lout_toast!!.visibility = GONE }, 2200)
    }

    fun intView(c: Context?) {
        applicationContext = c
        view = LayoutInflater.from(applicationContext).inflate(R.layout.activity_gesturelockactivity, this, true)
    /*  ---Ankita----
      if (datas == null || datas.equals("", ignoreCase = true)) {
            datas = applicationContext!!.packageName
        }
        lout_toast = findViewById(R.id.lout_toast)
        lout_forgot_dialog = findViewById(R.id.lout_forgot_dialog)
        txt_toast_msg = findViewById(R.id.txt_toast_msg)
        lout_toast.setVisibility(GONE)
        lout_forgot_dialog.setVisibility(GONE)
        lout_forgot_dialog.setOnClickListener(OnClickListener { })
        try {
            surfaceView = findViewById<View>(R.id.picSurfaceView) as SurfaceView
            cameraFuncation = CameraFuncation(applicationContext, surfaceView)
            shakeanimation = AnimationUtils.loadAnimation(applicationContext, R.anim.shake)

            //----------------check internet connection-----------------
            cd = ConnectionDetector(applicationContext)
            isInternetPresent = cd!!.isConnectingToInternet

            //-----------------------set background image-------------------------------
            val bitmap: Bitmap
            rootview = findViewById<View>(R.id.rootview) as LinearLayout
            if (getThemeType(applicationContext, Constant.THEME_TYPE) != packageName) {
                rootview!!.background = getBitmap(
                    applicationContext, DIGIT_BG
                )
                bitmap = (getBitmap(
                    applicationContext,
                    DIGIT_BG
                ) as BitmapDrawable).bitmap
            } else {
                if (getBitmap(applicationContext, DIGIT_BG) == null) {
                    rootview!!.setBackgroundResource(R.drawable.applock_0)
                    bitmap = BitmapFactory.decodeResource(resources, R.drawable.applock_0)
                } else {
                    rootview!!.background = getBitmap(
                        applicationContext, DIGIT_BG
                    )
                    bitmap = (getBitmap(
                        applicationContext,
                        DIGIT_BG
                    ) as BitmapDrawable).bitmap
                }
            }
            val d: Drawable = BitmapDrawable(
                resources, bitmap
            )
            rootview!!.setBackgroundDrawable(d)
            //rootview.setAlpha(0.5f);

            //---------set apps name ,icon and forget password------------------------------
            img_dot = findViewById<View>(R.id.img_dot) as ImageView
            val tvForgotPass = findViewById<TextView>(R.id.tvForgotPass)
            val tvCancel = findViewById<TextView>(R.id.tvCancel)
            tvCancel.visibility = GONE
            tvForgotPass.setOnClickListener { view: View? -> displaysecurityDialogue() }
            try {
                icon = applicationContext!!.packageManager.getApplicationIcon(datas!!)
            } catch (e: PackageManager.NameNotFoundException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
            }
            img_dot!!.setImageDrawable(icon)

            //------------------------------Gesture lock coed--------------------------------------------
            gestures = findViewById<View>(R.id.gestures) as GestureOverlayView
            gestures!!.addOnGesturePerformedListener(handleGestureListener)
            gestures!!.gestureStrokeAngleThreshold = 90.0f
            mLibrary = GestureLibraries.fromFile(
                applicationContext!!.getExternalFilesDir(null).toString() + "/" + "gesture.txt"
            )
            mLibrary.load()
        } catch (e: Exception) {
        }*/
    }

    val packageName: String
        get() = applicationContext!!.packageName

    public override fun onAttachedToWindow() {
        super.onAttachedToWindow()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (listener != null) listener!!.onBackCloseLock()
        } else if (event.keyCode == KeyEvent.KEYCODE_HOME) {
        }
        return true
    }

    private val handleGestureListener: GestureOverlayView.OnGesturePerformedListener =
        object : GestureOverlayView.OnGesturePerformedListener {
            override fun onGesturePerformed(gestureView: GestureOverlayView, gesture: Gesture) {
                val predictions = mLibrary!!.recognize(gesture)

                // one prediction needed
                if (predictions.size > 0) {
                    val prediction = predictions[0]
                    // checking prediction
                    if (prediction.score >= 4) {
                        if (from_app) {
                            val i = Intent(applicationContext, MainActivity::class.java)
                            i.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            applicationContext!!.startActivity(i)
                        } else {
                            val currentapiVersion = Build.VERSION.SDK_INT
                            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP_MR1) {
                                val servicePreference = ServicePreference(applicationContext)
                                servicePreference.SetLockUnlock(true)
                                if (listener != null) {
                                    listener!!.onCloseLock()
                                }
                            } else {
                                SavePreferences("Lock", "True")
                                isCorrectPasswordEntered = true
                                if (currentapiVersion >= Build.VERSION_CODES.LOLLIPOP) {
//                                setResult(RESULT_OK);
//                                finish();
                                    if (listener != null) {
                                        listener!!.onCloseLock()
                                    }
                                } else {
//                                setResult(RESULT_OK);
//                                fini
//                                 if (listener!= null){
//                                listener.onCloseLock();
//                            }sh();
                                }
                            }
                        }
                    } else {
                        img_dot!!.startAnimation(shakeanimation)
                        passwordTry = passwordTry + 1
                        showToast("Enter correct password")
                        //Toast.makeText(getApplicationContext(), "Enter correct password", Toast.LENGTH_SHORT).show();
                        Handler().postDelayed({ // TODO Auto-generated method stub
                            val permission = Grant_Permission()
                            if (permission) {
                                if (passwordTry >= 1) {
                                    passwordTry = 0
                                    if (cameraFuncation != null) {
                                        cameraFuncation!!.tackPicture(datas)
                                    }
                                }
                            }
                        }, 600)
                    }
                }
            }
        }

    init {
        intView(context)
    }

    fun Grant_Permission(): Boolean {
        var permission = true
        permission = ActivityCompat.checkSelfPermission(
            applicationContext!!,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
        return permission
    }

    private fun SavePreferences(key: String, value: String) {
        val sharedPreferences = applicationContext!!.getSharedPreferences("pref", 0)
        val editor = sharedPreferences.edit()
        editor.putString(key, value)
        editor.commit()
    }

/*   ----Ankita----
 private fun showFilterPopup(v: View) {
        val wrapper: Context = ContextThemeWrapper(applicationContext, R.style.YourActionBarWidget)
        val popup = PopupMenu(wrapper, v)
        popup.menuInflater.inflate(R.menu.menu_popup_pattern, popup.menu)

        // Setup menu item selection
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_keyword -> {
                    displaysecurityDialogue()
                    true
                }

                else -> false
            }
        }
        // Handle dismissal with: popup.setOnDismissListener(...);
        // Show the menu
        popup.show()
    }*/

   /*-------Ankita------
   fun displaysecurityDialogue() {
        showAndHandleForgetPassword(
            applicationContext,
            view,
            object : OnForgetPasswordCustomViewListener {
                override fun onForgetPasswordDone(editAnswer: EditText) {
                    if (editAnswer.text.toString().trim { it <= ' ' } == getFromUserDefaults(
                            applicationContext, SECURITY_ANSWER
                        )) {
                        val imm =
                            applicationContext!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                        if (imm.isAcceptingText) {
                            //writeToLog("Software Keyboard was shown");
                            //  hideSoftKeyboard(binding.edtSearch);
                            val manager =
                                applicationContext!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                            manager.hideSoftInputFromWindow(view!!.windowToken, 0)
                        } else {
                            // writeToLog("Software Keyboard was not shown");
                        }
                        lout_forgot_dialog!!.visibility = GONE
                        val i = Intent(applicationContext, SavePatternLockActivty::class.java)
                        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        applicationContext!!.startActivity(i)
                        if (listener != null) listener!!.onCloseLock()
                    } else {
                        showToast(applicationContext!!.resources.getString(R.string.msg_answer_miss_matched))
                    }
                }

                override fun onForgetPasswordCancel() {
                    lout_forgot_dialog!!.visibility = GONE
                }
            })
    }*/

    companion object {
        private const val REQUEST_CODE_ASK_PERMISSIONS = 135
    }
}