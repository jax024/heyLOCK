package com.applock.lock.apps.fingerprint.password.view

class PackageInfoClass {
    var appId: String? = null
    @JvmField
	var status = false
    var appname: String? = null
    var appsIcon: String? = null
    var appsPackagename: String? = null
    var appsCategory: String? = null
    var appUseCount: Int? = null
}