package com.applock.lock.apps.fingerprint.password.view

object DataBaseField {
    const val packageid = "packageid"
    const val packagename = "packagename"
    const val flag = "flag"
    const val appname = "appname"
    const val appicon = "appicon"
    const val categoryname = "categoryname"
    const val appusecount = "appusecount"

    const val ID = "id"
    const val icon = "icon"
    const val desc = "desc"
}