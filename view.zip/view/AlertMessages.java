package com.applock.lock.apps.fingerprint.password.view;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;

public class AlertMessages {
	Context context;

	public AlertMessages(Context context) {
		this.context = context;
	}

	public void showNetworkAlert() {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage("Please Check Your Internet Connection.")
				.setPositiveButton("Ok", new OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});

		AlertDialog alert = builder.create();
		alert.setTitle("Connection Problem");
		alert.show();

	}

	public void showserverdataerror() {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage("No Data Found on Server.").setPositiveButton("Ok",
				new OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});

		AlertDialog alert = builder.create();

		alert.show();

	}

	public void Registered() {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage("Regestration Sucessfully").setPositiveButton("Ok",
				new OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});

		AlertDialog alert = builder.create();

		alert.show();

	}

	public void login() {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage("Log in Sucessfully").setPositiveButton("Ok",
				new OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});

		AlertDialog alert = builder.create();

		alert.show();

	}

	public void showErrornInConnection() {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage("Please check Your Internet Connection")
				.setCancelable(false)
				.setPositiveButton("Ok", new OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});

		AlertDialog alert = builder.create();
		alert.show();

	}

	public void showFriendAddError(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage(message).setCancelable(false)
				.setPositiveButton("Ok", new OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});

		AlertDialog alert = builder.create();
		alert.show();

	}

	public void showCutomMessage(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage(message).setCancelable(false)
				.setPositiveButton("Ok", new OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {

						dialog.cancel();

					}
				});

		AlertDialog alert = builder.create();
		alert.show();

	}

	public void showExitMessage(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage(message).setCancelable(false)
				.setPositiveButton("Ok", new OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {

						dialog.cancel();

					}
				});

		AlertDialog alert = builder.create();
		alert.show();

	}

}
