package com.applock.lock.apps.fingerprint.password.view

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DataBaseNew(ctx: Context?)
{
    var dbHelper: DatabaseHelper? = null
    var sqLiteDb: SQLiteDatabase? = null

    class DatabaseHelper internal constructor(ctx: Context?) :
        SQLiteOpenHelper(ctx, DATABASE_NAME, null, DATABASE_VERSION) {
        init {
            ct = ctx
        }

        override fun onCreate(db: SQLiteDatabase) {
            try {
                db.execSQL(buildApplockTableQuery())
                db.execSQL(buildBannerAdTableQuery())
            } catch (e: SQLException) {
//				Toast.makeText(ct, "Table not created", Toast.LENGTH_LONG)
//					.show();
            }
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
        @Synchronized
        override fun getWritableDatabase(): SQLiteDatabase {
            return super.getWritableDatabase()
        }
    }

    /**
     * Constructor
     */
    init {
        HCtx = ctx
    }

    @Throws(SQLException::class)
    fun open(): DataBaseNew {
        dbHelper = DatabaseHelper(HCtx)
        sqLiteDb = dbHelper!!.writableDatabase
        return this
    }

    fun close() {
        dbHelper!!.close()
    }

    @Synchronized
    fun insert(DATABASE_TABLE: String?, values: ContentValues?): Long {
        return sqLiteDb!!.insert(DATABASE_TABLE, null, values)
    }

    @Synchronized
    fun update(
        DATABASE_TABLE: String?,
        values: ContentValues?, whereClause: String?
    ): Long {
        return sqLiteDb!!.update(DATABASE_TABLE, values, whereClause, null).toLong()
    }

    @Synchronized
    fun delete(DATABASE_TABLE: String?, whereCause: String?): Boolean {
        return sqLiteDb!!.delete(DATABASE_TABLE, whereCause, null) > 0
    }

    @Synchronized
    fun deleteall(DATABASE_TABLE: String?): Boolean {
        return sqLiteDb!!.delete(DATABASE_TABLE, null, null) > 0
    }

    @Synchronized
    @Throws(SQLException::class)
    fun fetch(DATABASE_TABLE: String?, where: String?): Cursor {
        return sqLiteDb!!.query(
            DATABASE_TABLE, null, where, null, null,
            null, null
        )
    }

    @Synchronized
    fun fetchAll(DATABASE_TABLE: String?): Cursor? {
        return try {
            sqLiteDb!!.query(
                DATABASE_TABLE, null, null, null, null, null,
                null
            )
        } catch (e: Exception) {
            null
        }
    }

    @get:Throws(SQLException::class)
    val packageList: Cursor?
        get() {
            val mCursor = sqLiteDb!!.rawQuery("select * FROM Applock", null)
            mCursor?.moveToFirst()
            return mCursor
        }

    @Throws(SQLException::class)
    fun getPackageListUnique(packagename: String, flag: String): Cursor? {
        val mCursor = sqLiteDb!!.rawQuery(
            "select * FROM Applock where flag='"
                    + flag + "' and packagename='" + packagename + "'", null
        )
        mCursor?.moveToFirst()
        return mCursor
    }

    @Throws(SQLException::class)
    fun getPackageListUnique(flag: String): Cursor? {
        val mCursor = sqLiteDb!!.rawQuery(
            "select * FROM Applock where flag='"
                    + flag + "'", null
        )
        mCursor?.moveToFirst()
        return mCursor
    }

    @Throws(SQLException::class)
    fun getPackageList(packagename: String): Cursor? {
        val mCursor = sqLiteDb!!.rawQuery(
                "select * FROM Applock where packagename='"
                        + packagename + "'", null
            )
        mCursor?.moveToFirst()
        return mCursor
    }

    @Throws(SQLException::class)
    fun getPackageListFirsttime(packagename: String): Cursor? {
        val mCursor = sqLiteDb!!.rawQuery(
            "select * FROM AppInstall where packagename='" + packagename
                    + "'", null
        )
        mCursor?.moveToFirst()
        return mCursor
    }

    @Throws(SQLException::class)
    fun addPackageList(packagename: String, flag: String) {
        sqLiteDb!!.execSQL(
            "insert into Applock values(null,'" + packagename
                    + "','" + flag + "');"
        )
    }

    @Throws(SQLException::class)
    fun inserAppList(
        packagename: String, flag: String, appname: String,
        appicon: String ,  categoryname: String,  appusecount: Int
    ) {
        sqLiteDb!!.execSQL(
            "insert into Applock values(null,'" + packagename
                    + "','" + flag + "','" + appname + "','"+ appicon + "','"+ categoryname + "','" + appusecount + "');"
        )
    }

    @SuppressLint("SuspiciousIndentation")
    @Throws(SQLException::class)
    fun getAppListByAppUseCount(): Cursor? {

      val mCursor = sqLiteDb!!.rawQuery(
            "SELECT * FROM Applock ORDER BY appusecount DESC", null
        )
        mCursor?.moveToFirst()
        return mCursor

    /*    return sqLiteDb?.query(
            "Applock", // Table name
            null, // Projection: null to retrieve all columns
            null, // Selection
            null, // Selection args
            null, // Group by
            null, // Having
            "appusecount DESC"
        )*/
/*
        return sqLiteDb?.query(
            "Applock", // Table name
            null, // Projection: null to retrieve all columns
            null, // Selection
            null, // Selection args
            null, // Group by
            null, // Having
            "appusecount DESC", // Order by appusecount in descending order
            null // Limit (optional)
        )*/
    }

    @Throws(SQLException::class)
    fun getMaxAppUseCount(): Int {
        var maxAppUseCount = 0
        val cursor = sqLiteDb?.rawQuery("SELECT MAX(appusecount) FROM Applock", null)

        cursor?.use { cursor ->
            if (cursor.moveToFirst()) {
                maxAppUseCount = cursor.getInt(0) // Retrieves the maximum appusecount value
            }
        }

        return maxAppUseCount
    }

/*
    @Throws(SQLException::class)
    fun getAppListByCategory(categoryName: String): Cursor? {
     */
/*   if (!isCategoryExists(categoryName)) {
            Log.w("+++++", " isCategoryExists-----:NOOO " )
            return null
        }*//*

        val mCursor = sqLiteDb!!.rawQuery(
            "select * FROM Applock where categoryName='"
                    + categoryName + "'", null
        )
        mCursor?.moveToFirst()
        return mCursor
    }
*/



    @Throws(SQLException::class)
    fun getAppListByCategory(categoryName: String): Cursor? {
        val query = "SELECT * FROM Applock WHERE categoryName LIKE ?"
        val selectionArgs = arrayOf("%$categoryName%")
        val mCursor = sqLiteDb!!.rawQuery(query, selectionArgs)
        mCursor?.moveToFirst()
        return mCursor
    }

    @Throws(SQLException::class)
    fun getPlayertAppListByCategory(): Cursor? {
        if (!isCategoryExists("AUDIO")&& !isCategoryExists("VIDEO")) {
            return null
        }
        val categories = arrayOf("AUDIO", "VIDEO")
        val query = "SELECT * FROM Applock WHERE categoryName IN (?, ?)"
        val mCursor = sqLiteDb!!.rawQuery(
            query,
            categories
        )
        mCursor?.moveToFirst()
        return mCursor
    }
    @Throws(SQLException::class)
    fun isCategoryExists(categoryName: String): Boolean {
        val query = "SELECT COUNT(*) FROM Applock WHERE categoryName = ?"
        val selectionArgs = arrayOf(categoryName)
        val cursor = sqLiteDb!!.rawQuery(query, selectionArgs)

        var count = 0
        cursor.use { c ->
            if (c.moveToFirst()) {
                count = c.getInt(0)
            }
        }
        return count > 0
    }

    @Throws(SQLException::class)
    fun inserAppInstall(packagename: String, flag: String) {
        sqLiteDb!!.execSQL(
            "insert into AppInstall values(null,'" + packagename
                    + "','" + flag + "');"
        )
    }

    @Throws(SQLException::class)
    fun delete(packageName: String) {
        sqLiteDb!!.execSQL(
            "delete from Applock where packagename='"
                    + packageName + "' "
        )
    }

    @Throws(SQLException::class)
    fun updateAppList(packagename: String, flag: String): Cursor? {
        val mCursor = sqLiteDb!!.rawQuery(
            "update Applock set flag='" + flag
                    + "' where  packagename='" + packagename + "'", null
        )
        mCursor?.moveToFirst()
        return mCursor
    }

    @Throws(SQLException::class)
    fun insertBackList(url: String, flag: String, type: String) {
        sqLiteDb!!.execSQL(
            "insert into BackgroundImg values(null,'" + url
                    + "','" + flag + "','" + type + "');"
        )
    }

    @get:Throws(SQLException::class)
    val backList: Cursor?
        get() {
            val mCursor = sqLiteDb!!.rawQuery("select * FROM BackgroundImg", null)
            mCursor?.moveToFirst()
            return mCursor
        }

    @Throws(SQLException::class)
    fun getBackListoff(type: String): Cursor? {
        val mCursor = sqLiteDb!!.rawQuery(
            "select * FROM BackgroundImg where type='" + type
                    + "'  ORDER BY ID DESC ", null
        )
        mCursor?.moveToFirst()
        return mCursor
    }

    @get:Throws(SQLException::class)
    val backFirstimg: Cursor?
        get() {
            val mCursor = sqLiteDb!!.rawQuery(
                "select * FROM BackgroundImg limit 1", null
            )
            mCursor?.moveToFirst()
            return mCursor
        }

    @Throws(SQLException::class)
    fun getBackdecending(pageno: Int): Cursor? {
        val offset: Int
        offset = if (pageno == 0) {
            1
        } else {
            pageno * 10
        }
        val mCursor = sqLiteDb!!.rawQuery(
            "select * FROM BackgroundImg  limit 10 offset $offset", null
        )
        mCursor?.moveToFirst()
        return mCursor
    }

    @Throws(SQLException::class)
    fun getBackList(url: String): Cursor? {
        val mCursor = sqLiteDb!!.rawQuery(
            "select * FROM BackgroundImg where path='$url'", null
        )
        mCursor?.moveToFirst()
        return mCursor
    }

    @Throws(SQLException::class)
    fun getSdImg(flag: String): Cursor? {
        val mCursor = sqLiteDb!!.rawQuery(
            "select * FROM BackgroundImg where flag='$flag'", null
        )
        mCursor?.moveToFirst()
        return mCursor
    }

    @Throws(SQLException::class)
    fun deleteSdImg(id: String) {
        sqLiteDb!!.execSQL("delete from BackgroundImg where ID='$id' ")
    }

    @get:Throws(SQLException::class)
    val lastrecord: Cursor?
        get() {
            val mCursor = sqLiteDb!!.rawQuery(
                "select * FROM BackgroundImg ORDER BY ID DESC limit 1", null
            )
            mCursor?.moveToFirst()
            return mCursor
        }

    @Throws(SQLException::class)
    fun insertBanner(
        packagename: String, appname: String, icon: String,
        desc: String
    ) {
        sqLiteDb!!.execSQL(
            "insert into BannerAdd values(null,'" + packagename
                    + "','" + appname + "','" + icon + "','" + desc + "');"
        )
    }

    @Throws(SQLException::class)
    fun checkForUniqueRecord(packagename: String): Cursor? {
        val mCursor = sqLiteDb!!.rawQuery(
            "select * FROM BannerAdd where packagename='" + packagename
                    + "'", null
        )
        mCursor?.moveToFirst()
        return mCursor
    }

    @get:Throws(SQLException::class)
    val bannerAddData: Cursor?
        get() {
            val mCursor = sqLiteDb!!.rawQuery(
                "select * FROM BannerAdd ORDER BY RANDOM() LIMIT 1", null
            )
            mCursor?.moveToFirst()
            return mCursor
        }

    companion object {
        var ct: Context? = null
        private var HCtx: Context? = null
        const val DATABASE_NAME = "BannerAd"
        private const val DATABASE_VERSION = 1
        const val tbl_GetAppPackage = "getapppackage"
        const val Applock = "appLock"
        const val Applock1 = "applock1"
        const val BannerAdd = "banneradd"
        const val NEWS_TABLE_INT = 0
        private fun buildApplockTableQuery(): String {
            return ("create table " + Applock + "("
                    + DataBaseField.packageid + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + DataBaseField.packagename + " TEXT, "
                    + DataBaseField.flag + " TEXT, "
                    + DataBaseField.appname + " TEXT, "
                    + DataBaseField.appicon + " TEXT, "
                    + DataBaseField.categoryname + " TEXT, "
                    + DataBaseField.appusecount + " INTEGER); ")
        }

        private fun buildBannerAdTableQuery(): String {
            return ("create table " + BannerAdd + "(" + DataBaseField.ID
                    + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + DataBaseField.packagename + " TEXT, " + DataBaseField.appname
                    + " TEXT, " + DataBaseField.icon + " TEXT, "
                    + DataBaseField.desc + " TEXT); ")
        }
    }
}