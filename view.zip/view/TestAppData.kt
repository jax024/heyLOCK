package com.applock.lock.apps.fingerprint.password.view

import android.graphics.drawable.Drawable

class TestAppData(
    val appName: String,
    val packageName: String,
    val appIconDrawable: Drawable,
    val type: String
) {

    fun parsePackageName(): String {
        return packageName.substring(0, packageName.indexOf("/"))
    }

    fun toEntity(): LockedAppEntity {
        return LockedAppEntity(packageName)
    }
}