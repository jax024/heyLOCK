package com.applock.lock.apps.fingerprint.password.view

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DataBase {
    class DatabaseHelper internal constructor(ctx: Context?) :
        SQLiteOpenHelper(ctx, DATABASE_NAME, null, DATABASE_VERSION) {
        init {
            ct = ctx
        }

        override fun onCreate(db: SQLiteDatabase) {
            try {
                db.execSQL(buildNewsTableQuery())
            } catch (e: SQLException) {
//				Toast.makeText(ct, "Table not created", Toast.LENGTH_LONG)
//						.show();
            }
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
        @Synchronized
        override fun getWritableDatabase(): SQLiteDatabase {
            return super.getWritableDatabase()
        }
    }

    /**
     * Constructor
     */
    constructor(ctx: Context?) {
        HCtx = ctx
    }

    fun SetContext(context: Context?) {
        HCtx = context
    }

    constructor()

    @Throws(SQLException::class)
    fun open(): DataBase {
        dbHelper = DatabaseHelper(HCtx)
        sqLiteDb = dbHelper!!.writableDatabase
        return this
    }

    fun close() {
        try {
            if (sqLiteDb != null && sqLiteDb!!.isOpen) {
                sqLiteDb!!.close()
            }
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun insert(DATABASE_TABLE: String?, values: ContentValues?): Long {
        return sqLiteDb!!.insert(DATABASE_TABLE, null, values)
    }

    @Synchronized
    fun update(
        DATABASE_TABLE: String?,
        values: ContentValues?, whereClause: String?
    ): Long {
        return sqLiteDb!!.update(DATABASE_TABLE, values, whereClause, null).toLong()
    }

    @Synchronized
    fun delete(DATABASE_TABLE: String?, whereCause: String?): Boolean {
        return sqLiteDb!!.delete(DATABASE_TABLE, whereCause, null) > 0
    }

    @Synchronized
    fun deleteall(DATABASE_TABLE: String?): Boolean {
        return sqLiteDb!!.delete(DATABASE_TABLE, null, null) > 0
    }

    @Synchronized
    @Throws(SQLException::class)
    fun fetch(DATABASE_TABLE: String?, where: String?): Cursor {
        return sqLiteDb!!.query(
            DATABASE_TABLE, null, where, null, null,
            null, null
        )
    }

    @Synchronized
    fun fetchAll(DATABASE_TABLE: String?): Cursor? {
        return try {
            sqLiteDb!!.query(
                DATABASE_TABLE, null, null, null, null, null,
                null
            )
        } catch (e: Exception) {
            null
        }
    }

    /*near "SELECT": syntax error (code 1 SQLITE_ERROR): , while compiling: SELECT * FROM SELECT * FROM appLock WHERE packageName = 'com.amazing.secreateapplock' AND flag = 1*/
    @Synchronized
    fun getAppData(packageName: String): String? {
        val query = "getapppackage WHERE packagename = '$packageName' AND flag = 1"
        val cursor = sqLiteDb!!.query(query, null, null, null, null, null, null)
        return if (cursor != null && cursor.moveToNext()) {
            cursor.getString(cursor.getColumnIndexOrThrow("packagename"))
        } else null
    }

    companion object {
        var ct: Context? = null
        var dbHelper: DatabaseHelper? = null
        var sqLiteDb: SQLiteDatabase? = null
        var database: DataBase? = null
        private var HCtx: Context? = null
        const val DATABASE_NAME = "getpackage"
        private const val DATABASE_VERSION = 1
        const val tbl_GetAppPackage = "getapppackage"
        const val NEWS_TABLE_INT = 0
        private fun buildNewsTableQuery(): String {
            return ("create table " + tbl_GetAppPackage + "("
                    + DataBaseField.packageid
                    + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + DataBaseField.packagename + " TEXT, " + DataBaseField.flag
                    + " TEXT); ")
        }

        @JvmStatic
        @get:Synchronized
        val instance: DataBase?
            get() {
                if (sqLiteDb == null) {
                    database = DataBase(HCtx)
                    dbHelper = DatabaseHelper(HCtx)
                    sqLiteDb = dbHelper!!.writableDatabase
                }
                return database
            }
    }
}