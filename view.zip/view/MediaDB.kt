package com.applock.lock.apps.fingerprint.password.view

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class MediaDB(context: Context?) :
    SQLiteOpenHelper(context, database_NAME, null, database_VERSION)
{

    override fun onCreate(db: SQLiteDatabase) {
        val CREATE_IMAGE_TABLE = ("CREATE TABLE  IF NOT EXISTS " + table_images + " ( "
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + FILENAME + " TEXT, " + FILEPATH + " TEXT )")
        val CREATE_VIDEO_TABLE = ("CREATE TABLE  IF NOT EXISTS " + table_videos + " ( "
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + FILENAME + " TEXT, " + FILEPATH + " TEXT )")
        val CREATE_AUDIO_TABLE = ("CREATE TABLE  IF NOT EXISTS " + table_audios + " ( "
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + FILENAME + " TEXT, " + FILEPATH + " TEXT )")
        val CREATE_FILE_TABLE = ("CREATE TABLE  IF NOT EXISTS " + table_files + " ( "
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + FILENAME + " TEXT, " + FILEPATH + " TEXT )")
        val CREATE_HACK_TABLE = ("CREATE TABLE  IF NOT EXISTS " + table_hack + " ( "
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + FILEPATH + " TEXT, " + TIMESTAMP + " TEXT, " + PACKAGENAME
                + " TEXT )")
        db.execSQL(CREATE_IMAGE_TABLE)
        db.execSQL(CREATE_VIDEO_TABLE)
        db.execSQL(CREATE_AUDIO_TABLE)
        db.execSQL(CREATE_FILE_TABLE)
        db.execSQL(CREATE_HACK_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < newVersion) {
        }
    }

    var db: SQLiteDatabase? = null
    fun open() {
        db = this.writableDatabase
    }

    override fun close() {
        db!!.close()
    }

    fun insertImage(name: String?, path: String?) {
        Log.d("-------DB-------", "----insert-------${path}")

        val values = ContentValues()
        values.put(FILENAME, name)
        values.put(FILEPATH, path)
        db!!.insert(table_images, null, values)
    }


    @SuppressLint("Range")
    fun getAllImages(): ArrayList<String> {
        val imagesList = ArrayList<String>()
        val selectQuery = "SELECT $FILEPATH FROM $table_images"
        val db = this.readableDatabase
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery(selectQuery, null)
            if (cursor.moveToFirst()) {
                do {
                    val imagePath = cursor.getString(cursor.getColumnIndex(FILEPATH))
                    imagesList.add(imagePath)
                } while (cursor.moveToNext())
            }
        } catch (e: Exception) {
            Log.e("_____", "Error retrieving images from database: ${e.message}")
        } finally {
            cursor?.close()
            db.close()
        }

        return imagesList
    }



    @SuppressLint("Range")
    fun getAllAudios(): ArrayList<String> {
        val imagesList = ArrayList<String>()
        val selectQuery = "SELECT $FILEPATH FROM $table_audios"
        val db = this.readableDatabase
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery(selectQuery, null)
            if (cursor.moveToFirst()) {
                do {
                    val imagePath = cursor.getString(cursor.getColumnIndex(FILEPATH))
                    imagesList.add(imagePath)
                } while (cursor.moveToNext())
            }
        } catch (e: Exception) {
            Log.e("_____", "Error retrieving images from database: ${e.message}")
        } finally {
            cursor?.close()
            db.close()
        }

        return imagesList
    }

    @SuppressLint("Range")
    fun getAllFiles(): ArrayList<String> {
        val imagesList = ArrayList<String>()
        val selectQuery = "SELECT $FILEPATH FROM $table_files"
        val db = this.readableDatabase
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery(selectQuery, null)
            if (cursor.moveToFirst()) {
                do {
                    val imagePath = cursor.getString(cursor.getColumnIndex(FILEPATH))
                    imagesList.add(imagePath)
                } while (cursor.moveToNext())
            }
        } catch (e: Exception) {
            Log.e("_____", "Error retrieving images from database: ${e.message}")
        } finally {
            cursor?.close()
            db.close()
        }

        return imagesList
    }


    @SuppressLint("Range")
    fun getAllVideos(): ArrayList<String> {
        val imagesList = ArrayList<String>()
        val selectQuery = "SELECT $FILEPATH FROM $table_videos"
        val db = this.readableDatabase
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery(selectQuery, null)
            if (cursor.moveToFirst()) {
                do {
                    val imagePath = cursor.getString(cursor.getColumnIndex(FILEPATH))
                    imagesList.add(imagePath)
                } while (cursor.moveToNext())
            }
        } catch (e: Exception) {
            Log.e("_____", "Error retrieving images from database: ${e.message}")
        } finally {
            cursor?.close()
            db.close()
        }

        return imagesList
    }


    fun originalPath(name: String): String {
        var originalPath = ""
        val selectQuery = "SELECT " + FILEPATH + " FROM " + table_images + " WHERE " + FILENAME + "=?"
        val c = db!!.rawQuery(selectQuery, arrayOf(name))
        if (c.moveToFirst()) {
            originalPath = c.getString(c.getColumnIndexOrThrow(FILEPATH))
        }
        c.close()
        return originalPath
    }

    fun deletePath(name: String) {
        db!!.delete(table_images, FILENAME + " = ?", arrayOf(name))
    }

    fun insertVideo(name: String?, path: String?) {
        val values = ContentValues()
        values.put(FILENAME, name)
        values.put(FILEPATH, path)
        db!!.insert(table_videos, null, values)
    }

    fun originalPathVideo(name: String): String {
        var originalPath = ""
        val selectQuery =
            "SELECT " + FILEPATH + " FROM " + table_videos + " WHERE " + FILENAME + "=?"
        val c = db!!.rawQuery(selectQuery, arrayOf(name))
        if (c.moveToFirst()) {
            originalPath = c.getString(c.getColumnIndexOrThrow(FILEPATH))
        }
        c.close()
        return originalPath
    }

    fun deletePathVideo(name: String) {
        db!!.delete(table_videos, FILENAME + " = ?", arrayOf(name))
    }


    fun insertAudio(name: String?, path: String?) {
        val values = ContentValues()
        values.put(FILENAME, name)
        values.put(FILEPATH, path)
        db!!.insert(table_audios, null, values)
    }

    fun originalPathAudio(name: String): String {
        var originalPath = ""
        val selectQuery =
            "SELECT " + FILEPATH + " FROM " + table_audios + " WHERE " + FILENAME + "=?"
        val c = db!!.rawQuery(selectQuery, arrayOf(name))
        if (c.moveToFirst()) {
            originalPath = c.getString(c.getColumnIndexOrThrow(FILEPATH))
        }
        c.close()
        return originalPath
    }

    fun deletePathAudio(name: String) {
        db!!.delete(table_audios, FILENAME + " = ?", arrayOf(name))
    }

    fun insertFile(name: String?, path: String?) {
        val values = ContentValues()
        values.put(FILENAME, name)
        values.put(FILEPATH, path)
        db!!.insert(table_files, null, values)
    }

    fun originalPathFile(name: String): String {
        var originalPath = ""
        val selectQuery =
            "SELECT " + FILEPATH + " FROM " + table_files + " WHERE " + FILENAME + "=?"
        val c = db!!.rawQuery(selectQuery, arrayOf(name))
        if (c.moveToFirst()) {
            originalPath = c.getString(c.getColumnIndexOrThrow(FILEPATH))
        }
        c.close()
        return originalPath
    }

    fun deletePathFile(name: String) {
        db!!.delete(table_files, FILENAME + " = ?", arrayOf(name))
    }


    fun insertHackRow(path: String?, stamp: String?, app: String?) {
        val values = ContentValues()
        values.put(FILEPATH, path)
        values.put(TIMESTAMP, stamp)
        values.put(PACKAGENAME, app)
        db!!.insert(table_hack, null, values)
    }

    val hacks: List<Hack>
        get() {
            val list: MutableList<Hack> = ArrayList()
            val selectQuery = "SELECT * FROM " + table_hack
            val c = db!!.rawQuery(selectQuery, null)
            if (c.moveToFirst()) {
                do {
                    val path = c.getString(c.getColumnIndexOrThrow(FILEPATH))
                    val time = c.getString(c.getColumnIndexOrThrow(TIMESTAMP))
                    val appname = c.getString(c.getColumnIndexOrThrow(PACKAGENAME))
                    list.add(Hack(path, time, appname))
                } while (c.moveToNext())
            }
            c.close()
            return list
        }





    fun deleteHack() {
        val db = this.readableDatabase
        db!!.delete(table_hack, null, null)
        db.close()

    }
    fun deleteHackFile(path: String) {
        val db = this.readableDatabase
        db!!.delete(table_hack, FILEPATH + " = ?", arrayOf(path))
        db.close()

    }
    companion object {
        private const val database_VERSION = 2 // original database version 1 (live project)

        // database name
        private const val database_NAME = "MediaDB"
        private const val table_images = "Images"
        private const val table_videos = "Videos"
        private const val table_audios = "Audios"
        private const val table_files = "Files"
        private const val table_hack = "Hacks"
        private const val FILENAME = "filename"
        private const val FILEPATH = "filepath"
        private const val TIMESTAMP = "timestamp"
        private const val PACKAGENAME = "packageName"

    }
}