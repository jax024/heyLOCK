package com.applock.lock.apps.fingerprint.password.view

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.FrameLayout
import android.widget.TextView
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.utils.AppInterface
import com.applock.lock.apps.fingerprint.password.utils.FILE_NAME
import com.applock.lock.apps.fingerprint.password.utils.FILE_NAME_TEMP
import com.applock.lock.apps.fingerprint.password.utils.LOGIN_TYPE
import com.applock.lock.apps.fingerprint.password.utils.PIN
import com.applock.lock.apps.fingerprint.password.utils.getFromUserDefaults
import com.applock.lock.apps.fingerprint.password.utils.saveIntegerToUserDefaults
import com.applock.lock.apps.fingerprint.password.utils.saveToUserDefaults


class DonePasswordChangedDialog(private val activity: Activity) {
    private var dialog: Dialog? = null
    private var strType: String? = null
    private var strPin: String? = null
    private var onPasswordChangedDoneListener: AppInterface.OnPasswordChangedDoneListener? = null
    fun showDialog(
        strType: String?,
        strPin: String?,
        onPasswordChangedDoneListener: AppInterface.OnPasswordChangedDoneListener?
    ) {
        this.strType = strType
        this.strPin = strPin
        this.onPasswordChangedDoneListener = onPasswordChangedDoneListener
        Init()
    }

    private fun Init() {
        dialog = Dialog(activity)
        dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog!!.setContentView(R.layout.lout_password_changed)
        dialog!!.setCancelable(true)
        dialog!!.window!!
            .setLayout(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        dialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog!!.window!!.setGravity(Gravity.BOTTOM)
        val txtDone = dialog!!.findViewById<TextView>(R.id.txtDone)
        val txtCancel = dialog!!.findViewById<TextView>(R.id.txtCancel)
        txtDone.setOnClickListener { v: View? ->
            try {
                dialog!!.dismiss()
                if (strType == "0") {
                   saveIntegerToUserDefaults(activity, LOGIN_TYPE, 0)
                   saveToUserDefaults(activity, PIN, strPin)
                } else if (strType == "1") {
                   saveToUserDefaults(
                        activity, FILE_NAME,getFromUserDefaults(
                            activity, FILE_NAME_TEMP
                        )
                    )
                   saveIntegerToUserDefaults(activity, LOGIN_TYPE, 1)
                   saveToUserDefaults(activity, PIN, strPin)
                }
                onPasswordChangedDoneListener!!.onPasswordChangedDone()



            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        txtCancel.setOnClickListener { v: View? ->
            try {
                dialog!!.dismiss()
                onPasswordChangedDoneListener!!.onPasswordChangedDone()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        dialog!!.show()
    }
}