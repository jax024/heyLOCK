package com.applock.lock.apps.fingerprint.password.view

class Hack(@JvmField var path: String, @JvmField var timestamp: String, var app: String)