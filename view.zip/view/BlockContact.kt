package com.applock.lock.apps.fingerprint.password.view

import android.graphics.drawable.Drawable

class BlockContact {
    @JvmField
    var id: String? = null
    @JvmField
    var contactNumber: String? = null
    @JvmField
    var contactName: String? = null
    var isSelected = false
    @JvmField
    var bgDrawable: Drawable? = null
}