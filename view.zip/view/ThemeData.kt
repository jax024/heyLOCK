package com.applock.lock.apps.fingerprint.password.view

class ThemeData {
    @JvmField
    var packagename: String? = null
    @JvmField
    var banner_img: String? = null
    @JvmField
    var theme_id: String? = null
    @JvmField
    var banner_name: String? = null
    @JvmField
    var is_download = false
    override fun toString(): String {
        return "ThemeData{" +
                "packagename='" + packagename + '\'' +
                ", banner_img='" + banner_img + '\'' +
                ", theme_id='" + theme_id + '\'' +
                ", banner_name='" + banner_name + '\'' +
                ", is_download='" + is_download + '\'' +
                '}'
    }

    override fun equals(`object`: Any?): Boolean {
        var sameSame = false
        if (`object` != null && `object` is ThemeData) {
            sameSame = packagename == `object`.packagename
        }
        return sameSame
    }
}