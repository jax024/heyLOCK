package com.applock.lock.apps.fingerprint.password.view

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout

class AppInstalledDialogService : Service() {
    var windowManager: WindowManager? = null
    var params: WindowManager.LayoutParams? = null
    var view: View? = null
    var appName: String? = ""
    var packageNameM: String? = ""
    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        if (intent != null) {
            appName = intent.getStringExtra("app_name")
            packageNameM = intent.getStringExtra("package_name")
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val layoutFlag: Int
        layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        params = WindowManager.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    or WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSPARENT
        )
        params!!.width = FrameLayout.LayoutParams.WRAP_CONTENT
        params!!.height = FrameLayout.LayoutParams.WRAP_CONTENT
        params!!.gravity = Gravity.CENTER
        if (windowManager != null) {
            /* if (checkDrawerPermission())
             {
                 view = View.inflate(baseContext, R.layout.dailogue_addmessage, null)
                 val imageView = view!!.findViewById<ImageView>(R.id.ivappicon)
                 Glide.with(this).load(R.drawable.app_icon).into(imageView)
                 (view!!.findViewById<View>(R.id.tvAppNmae) as TextView).text = appName.toString()
                 view!!.findViewById<View>(R.id.tvlater)
                     .setOnClickListener { v: View? -> hideLock(view!!) }
                 view!!.findViewById<View>(R.id.tvlovck).setOnClickListener { v: View? ->
                     val values = ContentValues()
                     values.put("packagename", packageName.toString())
                     values.put("flag", "1")
                     val db1 = DataBase.getInstance()
                     db1.open()
                     val Id = db1.insert(DataBase.tbl_GetAppPackage, values)
                     db1.close()
                     val db = DataBaseNew(this)
                     db.open()
                     db.updateAppList(packageName, "1")
                     db.close()
                     hideLock(view)
                 }
                 view!!.setOnTouchListener(object : View.OnTouchListener {
                     var X_Axis = 0
                     var Y_Axis = 0
                     var TouchX = 0f
                     var TouchY = 0f
                     var lastX = 0f
                     var lastY = 0f
                     var currX = 0f
                     var currY = 0f
                     var startTouchTime = 0f
                     override fun onTouch(v: View, event: MotionEvent): Boolean {
                         val index = event.actionIndex
                         when (event.action) {
                             MotionEvent.ACTION_DOWN -> {
                                 X_Axis = params!!.x
                                 Y_Axis = params!!.y
                                 TouchX = event.rawX
                                 TouchY = event.rawY
                                 lastX = event.x
                                 lastY = event.y
                                 startTouchTime = System.currentTimeMillis().toFloat()
                                 //Log.d("TAG213", "onTouch: " + params.x + "Action down");
                                 return true
                             }

                             MotionEvent.ACTION_UP -> {
                                 //Log.d("TAG...", "" + params.x + " " + v.getWidth());
                                 currX = event.x
                                 currY = event.y
                                 val distance =
                                     Math.sqrt(((currX - lastX) * (currX - lastX) + (currY - lastY) * (currY - lastY)).toDouble())
                                         .toFloat()
                                 val speed = distance / (System.currentTimeMillis() - startTouchTime)
                                 //Log.d("TAG1212", "onTouch: " + speed + " " + ((System.currentTimeMillis() - startTouchTime) / 1000) + " " + distance);
                                 if ((params!!.x < -(v.width / 2) || params!!.x > v.width / 2) && distance > 80) {
                                     hideLock(view)
                                     stopSelf()
                                 } else {
                                     if (params!!.x < 0) {
                                         params!!.x = 0
                                         windowManager!!.updateViewLayout(view, params)
                                     }
                                     if (params!!.x > 0) {
                                         params!!.x = 0
                                         windowManager!!.updateViewLayout(view, params)
                                     }
                                 }
                                 //Log.d("TAG213", "onTouch: " + params.x + "Action Up");
                                 return true
                             }

                             MotionEvent.ACTION_MOVE -> {
                                 params!!.x = X_Axis + (event.rawX - TouchX).toInt()
                                 params!!.y = Y_Axis + (event.rawY - TouchY).toInt()
                                 //Log.d("TAG213", "onTouch: " + params.x + "Action Move");
                                 windowManager!!.updateViewLayout(view, params)
                                 return true
                             }

                             MotionEvent.ACTION_CANCEL -> return true
                         }
                         return false
                     }
                 })

                 *//*view.setOnKeyListener((view, keyCode, keyEvent) -> {
                    Log.d("TAG", "ON_BACK_PRESS_1 >>> KEY >>> "+keyCode);
                    try{
                        if (keyEvent.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                            Log.d("TAG", "ON_BACK_PRESS_2 >>> KEY >>> "+keyCode);
                            if (view != null && windowManager != null) {
                                windowManager.removeView(view);
                                stopSelf();
                                return true;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return false;
                });*//*windowManager!!.addView(view, params)
            }*/
        }
        return START_STICKY
    }

    private fun hideLock(view: View?) {
        try {
            if (view != null && windowManager != null) {
                windowManager!!.removeView(view)
                stopSelf()
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }

    private fun checkDrawerPermission(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) return false
        }
        return true
    }
}