package com.applock.lock.apps.fingerprint.password.view

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.MenuItem
import android.view.SurfaceView
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.view.ContextThemeWrapper
import androidx.fragment.app.FragmentActivity
import com.applock.lock.apps.fingerprint.password.R
import com.applock.lock.apps.fingerprint.password.activity.MainActivity
import com.applock.lock.apps.fingerprint.password.lock.Lock9View
import com.applock.lock.apps.fingerprint.password.lock.Lock9View1
import com.applock.lock.apps.fingerprint.password.utils.AppInterface
import com.applock.lock.apps.fingerprint.password.utils.CameraFuncation
import com.applock.lock.apps.fingerprint.password.utils.ConnectionDetector
import com.applock.lock.apps.fingerprint.password.utils.PATTERN_BG
import com.applock.lock.apps.fingerprint.password.utils.PIN
import com.applock.lock.apps.fingerprint.password.utils.ServicePreference
import com.applock.lock.apps.fingerprint.password.utils.THEME_TYPE
import com.applock.lock.apps.fingerprint.password.utils.getBitmap
import com.applock.lock.apps.fingerprint.password.utils.getFromUserDefaults
import com.applock.lock.apps.fingerprint.password.utils.getThemeType
import com.applock.lock.apps.fingerprint.password.utils.hideStatusBarAndNavigationBar
import java.util.Random

class PatternLockActivity : FragmentActivity() {
    var isInternetPresent = false
    var cd: ConnectionDetector? = null
    var message: AlertMessages? = null
    var mRegisterTask: AsyncTask<Void, Void, Void>? = null
    var icon: Drawable? = null
    var packagename: String? = null
    var rootview: LinearLayout? = null
    var img_dot: ImageView? = null
    var datas: String? = null
    var from_app = false
    var count = 0
    var passwordTry = 0
    var isCorrectPasswordEntered = false
    var lock9View: Lock9View1? = null
    var Onclick = View.OnClickListener { // TODO Auto-generated method stub
        /*switch (v.getId()) {
                  case R.id.ivpopup:
                      //showFilterPopup(v);
                      break;

                  default:
                      break;
              }*/
    }
    private var cameraFuncation: CameraFuncation? = null
    private var surfaceView: SurfaceView? = null
    private var CorrectPattern: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideStatusBarAndNavigationBar(this)
        setContentView(R.layout.patternlock_activity)
        cd = ConnectionDetector(this@PatternLockActivity)
        isInternetPresent = cd!!.isConnectingToInternet

        //adView = (AdView) findViewById(R.id.adView_lock_pattern);

        //------------------Initialize------------
        Init()
        if (from_app) {
//            loadAds.LoadBanner(adView);
        }
        val rand = Random()
        val n = rand.nextInt(3)
        //Log.d("random",""+n);
        if (n == 1) {
            AdLoard()
        }
    }

    fun Init() {
        //Log.d("TAG", "INIT >>> PATTERN_LOCK_ACTIVITY");
        surfaceView = findViewById<View>(R.id.picSurfaceView) as SurfaceView
        cameraFuncation = CameraFuncation(applicationContext, (surfaceView)!!)
        lock9View = findViewById<View>(R.id.lock_9_view) as Lock9View1
        rootview = findViewById<View>(R.id.rootview) as LinearLayout

        //-----------------------set background blur image-------------------------------
        if (getThemeType(applicationContext, THEME_TYPE) != packageName) {
            rootview!!.setBackgroundDrawable(
                getBitmap(
                    applicationContext, PATTERN_BG
                )
            )
        } else {
            if (getBitmap(applicationContext, PATTERN_BG) == null) {
                rootview!!.setBackgroundResource(R.drawable.applock_0)
            } else {
                rootview!!.setBackgroundDrawable(
                    getBitmap(
                        applicationContext, PATTERN_BG
                    )
                )
            }
            //rootview.setBackgroundResource(R.drawable.applock_0);
        }

        //---------set apps name ,icon and forget password------------------------------
        img_dot = findViewById<View>(R.id.img_dot) as ImageView
        val tvForgotPass = findViewById<TextView>(R.id.tvForgotPass)
     //   val tvCancel = findViewById<TextView>(R.id.tvCancel)
       // tvCancel.setOnClickListener { view: View? -> onBackPressed() }
        tvForgotPass.setOnClickListener { view: View? -> displaysecurityDialogue() }
        try {
            val extras = intent.extras
            if (extras != null) {
                datas = extras.getString("Packagename")
                from_app = intent.getBooleanExtra("from_app", false)
            }
            try {
                if (datas != null) {
                    icon = packageManager.getApplicationIcon(datas!!)
                } else {
                    icon = packageManager.getApplicationIcon(packageName)
                }
            } catch (e: PackageManager.NameNotFoundException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
            }
            img_dot!!.setImageDrawable(icon)
        } catch (e: Exception) {
        }

        //--------------------------------------------------------------------------------------
        lock9View!!.setCallBack(object : Lock9View1.CallBack
        {
            override fun onFinish(password: String?)
            {
                try {
                    CorrectPattern = getFromUserDefaults(
                        applicationContext, PIN
                    )
                    if (CorrectPattern != null) {
                        if (password != CorrectPattern) {
                            //---camera start-------
                            passwordTry = passwordTry + 1
                            if (passwordTry >= 1) {
                                passwordTry = 0
                                if (cameraFuncation != null) {
                                    cameraFuncation!!.tackPicture(datas)
                                }
                            }
                            val shake =
                                AnimationUtils.loadAnimation(this@PatternLockActivity, R.anim.shake)
                            img_dot!!.startAnimation(shake)
                        } else {
                            //--------------correct password--
                            if (from_app) {
                                val i = Intent(this@PatternLockActivity, MainActivity::class.java)
                                startActivityForResult(i, 58)
                            }
                            else
                            {
                                if (Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP_MR1) {
                                    val servicePreference = ServicePreference(
                                        applicationContext
                                    )
                                    servicePreference.SetLockUnlock(true)
                                    setResult(Activity.RESULT_OK)
                                    finish()
                                } else {
                                    SavePreferences("Lock", "True")
                                    isCorrectPasswordEntered = true
                                    setResult(Activity.RESULT_OK)
                                    finish()
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                }
            }
        })
    }

    fun GetExistingPatternLock(): String? {
        val preferences = getSharedPreferences("Patternlockpassword", Context.MODE_PRIVATE)
        return preferences.getString("PatternLock", null)
    }

    private fun showFilterPopup(v: View) {
        val wrapper: Context = ContextThemeWrapper(
            applicationContext,
            R.style.YourActionBarWidget
        )
        val popup = PopupMenu(wrapper, v)
        popup.menuInflater.inflate(
            R.menu.menu_popup_pattern,
            popup.menu
        )

        // Setup menu item selection
        popup.setOnMenuItemClickListener(object : PopupMenu.OnMenuItemClickListener {
            override fun onMenuItemClick(item: MenuItem): Boolean {
                when (item.itemId) {
                    R.id.menu_keyword -> {
                        displaysecurityDialogue()
                        return true
                    }
                    else -> return false
                }
            }
        })
        // Handle dismissal with: popup.setOnDismissListener(...);
        // Show the menu
        popup.show()
    }

    override fun onPause() {
        // TODO Auto-generated method stub
        //Log.d("onpause", "true");
        super.onPause()
    }

    override fun onStart() {
        // TODO Auto-generated method stub
        super.onStart()
        // to lock app while minimize and reopen
        // SavePreferences("Lock", "True");
        isCorrectPasswordEntered = false
    }

    override fun onStop() {
        // TODO Auto-generated method stub
        super.onStop()
        if (!isCorrectPasswordEntered) {
            SavePreferences("Lock", "False")
        }
    }

    private fun SavePreferences(key: String, value: String) {
        val sharedPreferences = getSharedPreferences("pref", 0)
        val editor = sharedPreferences.edit()
        editor.putString(key, value)
        editor.commit()
    }

    private fun getpreferences(key: String): String? {
        val sharedPreferences = getSharedPreferences("pref", 0)
        return sharedPreferences.getString(key, "0")
    }

    override fun onBackPressed() {
        count++
        if (count < 2) {
            Toast.makeText(this@PatternLockActivity, "Press again to exit!", Toast.LENGTH_SHORT)
                .show()
        } else {
            val startMain = Intent(Intent.ACTION_MAIN)
            startMain.addCategory(Intent.CATEGORY_HOME)
            startMain.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(startMain)
        }
    }

    fun displaysecurityDialogue() {
        ForgotPasswordDialog(this).showDialog(object: AppInterface.OnForgetPasswordDialogListener {
            override fun onForgetPasswordDone() {
                val i = Intent(this@PatternLockActivity, SavePatternLockActivty::class.java)
                startActivityForResult(i, 2)
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        //Log.d("onactivity result", "true");
        setResult(Activity.RESULT_OK)
        finish()
    }

    fun AdLoard() {
        //loadAds= LoadAds.getInstance(this);
        //loadAds.loadInterstitialAd(this,1);
    }

    companion object {
        private val TAG = PatternLockActivity::class.java.simpleName
        var name: String? = null
        var email: String? = null
        var acc_type: String? = null
        var package_name: String? = null
        var track_country: String? = null
        var DeviceId: String? = null

        /*   private MaterialLockView materialLockView;*/ //AdView adView;
        fun StringToBitMap(encodedString: String?): Bitmap? {
            return try {
                val encodeByte =
                    Base64.decode(encodedString, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(
                    encodeByte, 0,
                    encodeByte.size
                )
            } catch (e: Exception) {
                e.message
                null
            }
        }
    }
}